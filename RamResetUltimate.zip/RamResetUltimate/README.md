# RAM Reset Ultimate — KAIKODEV

Aplicativo Android nativo de **diagnóstico e otimização de memória**, honesto e funcional, **sem root**.

> **A verdade sobre "resetar/aumentar RAM":** nenhum app Android sem root consegue aumentar a
> memória física do aparelho nem limpar a RAM de outros apps. O kernel não permite. Apps que
> "mostram RAM liberada" com uma animação estão simulando. Este app **não simula**: ele lê dados
> reais via APIs oficiais, otimiza o próprio processo de verdade e leva você às telas oficiais do
> Android para o resto. Cada número vem do sistema; cada operação indisponível é declarada.

---

## 📐 Arquitetura

Clean Architecture + MVVM, 100% Kotlin + Jetpack Compose.

```
app/
 └─ src/main/java/com/kaikodev/ramreset/
     ├─ core/            # Motor: leitura e otimização reais (sem Android UI)
     │   ├─ MemoryAnalyzer.kt          ActivityManager.MemoryInfo + Debug.MemoryInfo (PSS)
     │   ├─ MemoryPressureDetector.kt  Classificação NORMAL/MODERATE/HIGH/CRITICAL (lógica pura)
     │   ├─ RamOptimizer.kt            Operações reais no PRÓPRIO app (cache, trim, GC)
     │   ├─ ResetEngine.kt             Orquestra antes→otimiza→depois→relatório
     │   ├─ ZramReader.kt              /proc/meminfo + /sys/block/zram0 (quando legível)
     │   ├─ StorageAnalyzer.kt         StatFs + cache próprio
     │   ├─ SystemDiagnostics.kt       Bateria, CPU, modelo, uptime
     │   ├─ AppAnalyzer.kt             Apps visíveis (respeita visibilidade do Android 11+)
     │   ├─ SystemShortcuts.kt         Intents para telas oficiais do Android
     │   ├─ model/                     Data classes (MemorySnapshot, ResetReport, etc.)
     │   └─ util/Formatters.kt         Conversão de unidades (testada)
     ├─ data/
     │   └─ HistoryRepository.kt       Persistência com DataStore (histórico real)
     └─ ui/
         ├─ theme/                     Preto profundo + roxo neon + azul elétrico
         ├─ components/                Gauge circular, gráfico de linha, cards premium
         ├─ navigation/                NavHost + barra inferior
         ├─ screens/                   11 telas
         └─ MainViewModel.kt           StateFlow, coroutines, monitoramento cancelável
```

## 🧩 Tecnologias

- **Kotlin 2.0**, **Jetpack Compose** (BOM 2024.12), **Material 3**
- **Coroutines + StateFlow**, **Navigation Compose**, **DataStore Preferences**
- **minSdk 26 (Android 8.0)** · targetSdk 35 · JDK 17
- Gradle 8.11 (Kotlin DSL + version catalog)

## ✅ Funcionalidades realmente implementadas

| Módulo | O que faz de verdade |
|---|---|
| **Limpeza Profunda** | **Limpa o cache de TODOS os apps** via serviço de acessibilidade: abre as configs de cada app e toca em "Limpar cache" automaticamente (é o Android que apaga). Nunca toca em "Limpar dados". |
| **Boost** | Lista apps usados recentemente (UsageStats, com "Acesso ao uso") para fechar via Forçar parada; lê a escala de animação e atalha p/ reduzi-la (menos lag). |
| RAM Monitor | Lê RAM total/disponível/uso%/lowMemory + PSS do app; gráfico com **histórico real** |
| Reset Engine | Apaga cache do próprio app, `onTrimMemory`, GC; mede antes/depois; relatório honesto |
| Pressão de memória | Classifica NORMAL→CRÍTICA por indicadores reais; marca quando é estimativa |
| ZRAM Intelligence | Lê swap de `/proc/meminfo`; tenta ZRAM e avisa quando o acesso é limitado |
| Smart Optimizer | Diagnóstico de sistema/bateria/armazenamento + atalhos oficiais do Android |
| Game Booster | Monitoramento leve + recomendações (sem prometer FPS artificial) |
| Storage Optimizer | Espaço total/usado/livre + cache próprio + atalho de gerenciamento |
| Histórico | Guarda cada otimização com DataStore (persistente) |

## 🧹 Limpeza de cache de TODOS os apps (sem root, de verdade)

A tela **Limpeza Profunda** usa um **serviço de acessibilidade** (`CacheCleanAccessibilityService`)
que o usuário ativa manualmente. Com ele ligado, o app percorre os apps instalados, abre a tela de
cada um e toca em **"Limpar cache"** por você — quem apaga o cache é o próprio Android. É a mesma
técnica que apps de limpeza sérios usam sem root.

- Só age **durante** uma limpeza iniciada por você; fora disso ignora tudo.
- **Nunca** toca em "Limpar dados"/"Limpar armazenamento" (o filtro exige a palavra *cache* e exclui
  *dados/armazenamento*).
- Não coleta nem envia nada.

## 🚫 O que NÃO é possível sem root (declarado no app, não simulado)

- Encerrar processos de **outros** apps automaticamente (o Boost leva você ao "Forçar parada" oficial)
- Liberar RAM usada por **outros** apps
- **Aumentar a RAM física** do aparelho
- Alterar parâmetros de ZRAM/kernel
- Mudar sozinho a escala de animação (exige ADB; o app lê o valor e atalha para você ajustar)

Para esses casos, o app abre a **tela oficial do Android**, onde o próprio sistema faz a ação.

---

## 🔨 Como compilar

### Opção A — Android Studio (local)
1. Abra a pasta do projeto no **Android Studio** (Koala ou mais novo).
2. O Studio baixa o SDK e regenera o Gradle Wrapper automaticamente.
3. `Run ▶` num emulador ou aparelho, ou **Build > Build APK(s)**.

### Opção B — GitHub Actions (nuvem, gera o APK pra você)
Este repositório já vem com `.github/workflows/android-build.yml`. A cada push na `main`
(ou manualmente em **Actions ▸ Android Build ▸ Run workflow**), a pipeline:

1. configura JDK 17 + Android SDK + Gradle 8.11;
2. roda os testes unitários;
3. compila o APK debug;
4. confere se `app/build/outputs/apk/debug/app-debug.apk` existe;
5. publica o APK como **artefato** para download.

**Baixar o APK:** aba *Actions* → a execução mais recente → seção *Artifacts* → `RamResetUltimate-debug-apk`.

## 📲 Como instalar o APK no Android
1. Baixe o artefato e extraia o `app-debug.apk`.
2. No celular, ative **"Instalar apps desconhecidos"** para o seu navegador/gerenciador de arquivos.
3. Abra o `.apk` e instale.

## 🧪 Testes
```
gradle testDebugUnitTest
```
Cobrem cálculos de memória, conversão de unidades, detecção de pressão e serialização do histórico.
Veja `app/src/test/`.

## 🔐 Segurança e privacidade
Sem root, sem ADB, sem coleta de dados, sem rede. Nenhuma senha/token no repositório
(a assinatura release fica fora do versionamento — ver `.gitignore`).

## 📄 Auditoria
Veja **[AUDITORIA.md](AUDITORIA.md)** para o detalhamento do que funciona, o que foi testado e o
que depende de permissões/limitações do Android.
