# Auditoria — RAM Reset Ultimate

Relatório honesto do que funciona, o que foi testado e o que depende de permissões ou
limitações do Android. (Atende às seções "Auditoria" e "Regra Final" das especificações.)

## 1. O que FUNCIONA de verdade (sem root)

| Função | Como | Evidência |
|---|---|---|
| RAM total/disponível/uso% | `ActivityManager.getMemoryInfo()` | Valores do próprio sistema |
| Estado de baixa memória | `MemoryInfo.lowMemory` | Flag autoritativa do SO |
| PSS do próprio app | `Debug.getMemoryInfo().totalPss` | Local ao processo, sem permissão |
| Histórico de uso | Coletado a cada 2s e desenhado no gráfico | `ramHistoryPercent` no ViewModel |
| Pressão de memória | Lógica pura sobre uso% + lowMemory | Testado em `PressureDetectorTest` |
| Liberar cache do próprio app | Apaga `cacheDir`/`externalCacheDir`; mede bytes | Medição antes/depois em `RamOptimizer` |
| **Limpar cache de TODOS os apps** | Serviço de acessibilidade toca em "Limpar cache" nas telas do Android | `CacheCleanAccessibilityService` (consentido pelo usuário) |
| Apps usados recentemente | `UsageStatsManager` (com "Acesso ao uso") | `UsageAnalyzer`; fechar é manual via Forçar parada |
| Escala de animação (anti-lag) | Lê `Settings.Global.*_ANIMATION_SCALE` | `PerformanceTuner`; ajuste via atalho às Opções do desenvolvedor |
| Trim de memória do app | `Context.onTrimMemory(RUNNING_CRITICAL)` | API oficial |
| GC/finalização | `Runtime.gc()` + `runFinalization()` | Hint ao runtime (não garantido) |
| Swap | `/proc/meminfo` (SwapTotal/SwapFree) | Arquivo world-readable |
| Armazenamento | `StatFs` em `getDataDirectory()` | API oficial |
| Bateria (nível/temp/saúde) | `ACTION_BATTERY_CHANGED` sticky intent | API oficial |
| Lista de apps visíveis | `PackageManager.getInstalledApplications` | Respeita visibilidade do Android 11+ |
| Atalhos do sistema | `Settings.ACTION_*` Intents | Abre telas oficiais |
| Histórico persistente | DataStore Preferences | `HistoryRepository` + teste de round-trip |

## 2. O que NÃO é possível sem root (declarado, nunca simulado)

| Pedido comum | Por que é impossível | O que o app faz no lugar |
|---|---|---|
| "Aumentar a RAM" | RAM é hardware; não se cria por software | Mostra RAM real e otimiza o que dá |
| "Limpar a RAM dos outros apps" | O Android gerencia e protege processos | Abre a tela do app p/ você forçar parada |
| "Matar apps em segundo plano" | `killBackgroundProcesses` é limitado e ignorado pelo SO | Atalho p/ configurações oficiais |
| Estatísticas de compressão ZRAM | `/sys/block/zram0/mm_stat` costuma exigir privilégio | Detecta e avisa "leitura limitada" |
| Mudar parâmetros do kernel/ZRAM | Exige root | Não tenta; apenas lê |

## 3. Honestidade dos resultados (seção 12)

O `ResetReport` separa claramente:
- **Ganho comprovado** = cache do próprio app liberado + redução de PSS do app (medidos).
- **Variação do sistema** = diferença de RAM disponível do SO, rotulada apenas como
  "variação observada" — **não** creditada como mérito do app, porque o Android move memória
  o tempo todo por conta própria.

O app nunca afirma "liberei X de RAM" sem medição.

## 4. Testes executados

`app/src/test/` (JUnit, roda na JVM, sem device):
- `MemoryCalculationsTest` — usado/disponível/percentual, bordas (total 0, valores inconsistentes).
- `UnitConversionTest` — B/KB/MB/GB, negativos, valores assinados.
- `PressureDetectorTest` — faixas NORMAL→CRÍTICA e override por `lowMemory`.
- `HistorySerializationTest` — round-trip e entradas malformadas.

A compilação e os testes rodam no GitHub Actions (`.github/workflows/android-build.yml`).

## 5. Permissões

| Permissão | Nível | Necessária? |
|---|---|---|
| `PACKAGE_USAGE_STATS` | Especial ("Acesso ao uso", à mão) | **Opcional** — lista apps recentes no Boost |
| Serviço de acessibilidade | Especial (ativado à mão) | **Opcional** — só para a Limpeza Profunda de cache |

As funções básicas (monitor, Reset Engine, diagnóstico, ZRAM, storage) **funcionam sem nenhuma
permissão especial**. Não usa `QUERY_ALL_PACKAGES`, não pede armazenamento, não acessa rede.
O serviço de acessibilidade só automatiza os toques de "Limpar cache" e nunca toca em "Limpar dados".

## 6. Compatibilidade

- minSdk 26 (Android 8.0) → targetSdk 35.
- Leituras de `/proc` e `/sys` são protegidas por try/catch: em aparelhos que bloqueiam o acesso,
  o campo vira `-1` e a UI mostra "—" em vez de quebrar.
- Recomendado testar o consumo próprio em aparelhos de 2 GB e 4 GB (ex.: Moto E13).

## 7. Limitações conhecidas

- O ganho de RAM do sistema após o reset pode ser pequeno ou nulo — e isso é **esperado** e
  honesto num app sem root. O valor real do produto é o **diagnóstico** e a orientação.
- Estatísticas detalhadas de ZRAM dependem do fabricante liberar leitura.
