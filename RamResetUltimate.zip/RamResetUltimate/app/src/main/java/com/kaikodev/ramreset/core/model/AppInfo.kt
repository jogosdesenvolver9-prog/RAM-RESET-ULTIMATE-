package com.kaikodev.ramreset.core.model

/** App instalado visível (seção 5). */
data class AppInfo(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    val isOwn: Boolean
)
