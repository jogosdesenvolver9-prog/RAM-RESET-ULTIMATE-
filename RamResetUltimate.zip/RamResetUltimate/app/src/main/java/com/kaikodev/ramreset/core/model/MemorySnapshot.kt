package com.kaikodev.ramreset.core.model

/**
 * Fotografia do estado de memória num instante.
 *
 * IMPORTANTE (seção 3.1 do spec):
 *  - [availableBytes] é "disponível", NÃO "totalmente livre". O Android conta
 *    como disponível também memória recuperável (caches, páginas limpas).
 *  - [usedBytes] é estimado = total - disponível. Não é soma de categorias.
 *
 * Todos os valores em bytes. Conversão para exibição fica nos Formatters.
 */
data class MemorySnapshot(
    val totalBytes: Long,
    val availableBytes: Long,
    val thresholdBytes: Long,      // abaixo disto o sistema considera "low memory"
    val lowMemory: Boolean,        // ActivityManager.MemoryInfo.lowMemory
    val appPssBytes: Long,         // PSS do próprio processo (Debug.MemoryInfo), -1 se indisponível
    val timestampMs: Long = System.currentTimeMillis()
) {
    /** Memória usada estimada = total - disponível (nunca negativa). */
    val usedBytes: Long get() = (totalBytes - availableBytes).coerceAtLeast(0L)

    /** Percentual de uso 0..100. Retorna 0 se total for 0 (dado inválido). */
    val usedPercent: Int
        get() = if (totalBytes <= 0L) 0
        else ((usedBytes.toDouble() / totalBytes.toDouble()) * 100.0).toInt().coerceIn(0, 100)

    val availablePercent: Int get() = (100 - usedPercent).coerceIn(0, 100)
}
