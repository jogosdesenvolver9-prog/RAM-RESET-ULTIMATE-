package com.kaikodev.ramreset.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.kaikodev.ramreset.core.model.ResetReport
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ramreset_history")

/**
 * Persistência local do histórico de otimizações (seção 15 / "Histórico").
 * Usa DataStore Preferences — leve, assíncrono, sem banco pesado.
 *
 * Cada entrada é serializada como linha "campo|campo|...".
 * Mantém no máximo [MAX_ENTRIES] para não crescer indefinidamente.
 */
class HistoryRepository(private val context: Context) {

    private val key = stringSetPreferencesKey("entries")

    val history: Flow<List<HistoryEntry>> = context.dataStore.data.map { prefs ->
        (prefs[key] ?: emptySet())
            .mapNotNull { HistoryEntry.deserialize(it) }
            .sortedByDescending { it.timestampMs }
    }

    suspend fun add(report: ResetReport) {
        val entry = HistoryEntry(
            timestampMs = report.timestampMs,
            availableBeforeBytes = report.before.availableBytes,
            availableAfterBytes = report.after.availableBytes,
            ownCacheFreedBytes = report.ownCacheFreedBytes,
            provenFreedBytes = report.provenFreedBytes,
            usedPercentBefore = report.before.usedPercent,
            usedPercentAfter = report.after.usedPercent
        )
        context.dataStore.edit { prefs ->
            val current = (prefs[key] ?: emptySet()).toMutableList()
            current.add(entry.serialize())
            // Mantém só as MAX_ENTRIES mais recentes.
            val trimmed = current
                .mapNotNull { HistoryEntry.deserialize(it) }
                .sortedByDescending { it.timestampMs }
                .take(MAX_ENTRIES)
                .map { it.serialize() }
                .toSet()
            prefs[key] = trimmed
        }
    }

    suspend fun clear() {
        context.dataStore.edit { it[key] = emptySet() }
    }

    companion object { const val MAX_ENTRIES = 50 }
}

/** Entrada compacta do histórico. */
data class HistoryEntry(
    val timestampMs: Long,
    val availableBeforeBytes: Long,
    val availableAfterBytes: Long,
    val ownCacheFreedBytes: Long,
    val provenFreedBytes: Long,
    val usedPercentBefore: Int,
    val usedPercentAfter: Int
) {
    fun serialize(): String = listOf(
        timestampMs, availableBeforeBytes, availableAfterBytes,
        ownCacheFreedBytes, provenFreedBytes, usedPercentBefore, usedPercentAfter
    ).joinToString("|")

    companion object {
        fun deserialize(raw: String): HistoryEntry? {
            val p = raw.split("|")
            if (p.size != 7) return null
            return try {
                HistoryEntry(
                    timestampMs = p[0].toLong(),
                    availableBeforeBytes = p[1].toLong(),
                    availableAfterBytes = p[2].toLong(),
                    ownCacheFreedBytes = p[3].toLong(),
                    provenFreedBytes = p[4].toLong(),
                    usedPercentBefore = p[5].toInt(),
                    usedPercentAfter = p[6].toInt()
                )
            } catch (_: Throwable) { null }
        }
    }
}
