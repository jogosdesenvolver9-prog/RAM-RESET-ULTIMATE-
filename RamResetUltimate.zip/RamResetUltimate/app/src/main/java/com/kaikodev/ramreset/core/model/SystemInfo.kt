package com.kaikodev.ramreset.core.model

/** Diagnóstico do sistema (seção 7). Campos nulos = indisponível nesta versão/hardware. */
data class SystemInfo(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val cpuCores: Int,
    val batteryPercent: Int?,          // null se indisponível
    val batteryCharging: Boolean?,
    val batteryTemperatureC: Float?,   // temperatura da BATERIA (não da CPU)
    val batteryHealth: String?,
    val uptimeMs: Long,
    val ramClassMb: Int                // ActivityManager.memoryClass (heap por app)
)
