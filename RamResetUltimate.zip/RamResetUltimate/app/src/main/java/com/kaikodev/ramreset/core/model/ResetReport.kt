package com.kaikodev.ramreset.core.model

/**
 * Relatório verificável de uma execução do Reset Engine (seções 6 e 12 do spec).
 * Guarda antes/depois reais e a lista honesta de operações executadas x indisponíveis.
 */
data class ResetReport(
    val timestampMs: Long,
    val before: MemorySnapshot,
    val after: MemorySnapshot,
    val ownCacheFreedBytes: Long,          // bytes de cache do próprio app realmente apagados
    val operationsDone: List<String>,      // o que foi efetivamente executado
    val operationsUnavailable: List<String>, // o que não é possível sem root/permissão
    val recommendations: List<String>
) {
    /** Variação de RAM disponível do sistema (pode ser negativa — e isso é honesto). */
    val systemAvailableDeltaBytes: Long get() = after.availableBytes - before.availableBytes

    /** Variação do PSS do próprio app (negativo = o app encolheu). */
    val ownPssDeltaBytes: Long
        get() = if (before.appPssBytes >= 0 && after.appPssBytes >= 0)
            after.appPssBytes - before.appPssBytes else 0L

    /**
     * Resultado honesto: só consideramos "ganho comprovado" o que medimos no PRÓPRIO app
     * (cache liberado + redução de PSS). A variação do sistema é informada, mas rotulada
     * como "variação observada", não como mérito garantido do app (seção 12).
     */
    val provenFreedBytes: Long
        get() = ownCacheFreedBytes + (if (ownPssDeltaBytes < 0) -ownPssDeltaBytes else 0L)
}
