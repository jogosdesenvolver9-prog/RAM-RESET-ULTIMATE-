package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard
import com.kaikodev.ramreset.ui.navigation.Routes
import com.kaikodev.ramreset.ui.theme.NeonPurple

@Composable
fun MoreScreen(nav: NavController) {
    ScreenScaffold(title = "Mais ferramentas") {
        SectionCard {
            MenuRow("Limpeza Profunda (cache de todos os apps)", Icons.Filled.CleaningServices) { nav.navigate(Routes.DEEP_CLEAN) }
            MenuRow("Boost (apps recentes + anti-lag)", Icons.Filled.RocketLaunch) { nav.navigate(Routes.BOOST) }
            MenuRow("ZRAM Intelligence", Icons.Filled.Compress) { nav.navigate(Routes.ZRAM) }
            MenuRow("Análise de apps", Icons.Filled.ViewList) { nav.navigate(Routes.APPS) }
            MenuRow("Storage Optimizer", Icons.Filled.Storage) { nav.navigate(Routes.STORAGE) }
            MenuRow("Game Booster", Icons.Filled.SportsEsports) { nav.navigate(Routes.GAME_BOOSTER) }
            MenuRow("Histórico", Icons.Filled.History) { nav.navigate(Routes.HISTORY) }
            MenuRow("Configurações", Icons.Filled.Settings) { nav.navigate(Routes.SETTINGS) }
        }
    }
}

@Composable
private fun MenuRow(title: String, icon: ImageVector, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeonPurple)
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(start = 14.dp).weight(1f)
        )
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
