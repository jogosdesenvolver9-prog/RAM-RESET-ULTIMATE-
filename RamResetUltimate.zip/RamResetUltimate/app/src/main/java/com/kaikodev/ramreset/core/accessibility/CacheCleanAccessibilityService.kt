package com.kaikodev.ramreset.core.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Limpa o cache de TODOS os apps selecionados automatizando as telas oficiais do Android.
 *
 * COMO FUNCIONA (sem root, técnica legítima e consentida):
 *  Para cada app da fila, o serviço:
 *   1. abre "Informações do app" (ACTION_APPLICATION_DETAILS_SETTINGS);
 *   2. toca na linha "Armazenamento e cache" (quando existe);
 *   3. toca em "Limpar cache".
 *  É o próprio sistema quem apaga o cache — o serviço apenas toca nos botões por você.
 *
 * SEGURANÇA:
 *  - NUNCA toca em "Limpar dados"/"Limpar armazenamento" (isso apagaria dados do app).
 *    O casamento de texto exige a palavra "cache" e exclui "dados/data/armazenamento/storage".
 *  - Só age enquanto há uma sessão ativa (CleanSession.isActive). Fora disso, ignora tudo.
 *
 * CONTROLE DE FLUXO:
 *  Existe SEMPRE no máximo um passo agendado ([stepRunnable]). Cada app tem um índice; o
 *  [advanceGuard] garante que avançamos uma única vez por índice, mesmo que vários eventos
 *  de tela cheguem. Isso evita pular apps.
 */
class CacheCleanAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val stepRunnable = Runnable { advance() }

    private var index = 0
    private var clickedStorage = false
    private var advanceGuard = -1

    override fun onServiceConnected() {
        super.onServiceConnected()
        INSTANCE = this
    }

    override fun onDestroy() {
        if (INSTANCE === this) INSTANCE = null
        handler.removeCallbacks(stepRunnable)
        super.onDestroy()
    }

    override fun onInterrupt() { /* obrigatório, sem ação */ }

    fun startClean(items: List<Pair<String, String>>) {
        if (items.isEmpty()) return
        CleanSession.begin(items)
        index = 0
        openCurrent()
    }

    fun cancel() {
        handler.removeCallbacks(stepRunnable)
        CleanSession.finish()
        returnToApp()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!CleanSession.isActive) return
        val root = rootInActiveWindow ?: return

        // 1) Botão "Limpar cache": clica e agenda o avanço (curto).
        val clear = findNode(root) { isClearCacheNode(it) }
        if (clear != null) {
            clickNodeOrAncestor(clear) // se o cache estiver vazio, o botão está desativado — tudo bem
            scheduleStep(AFTER_CLEAR_MS)
            return
        }

        // 2) Sem o botão: entra em "Armazenamento e cache". Não mexe no watchdog longo.
        if (!clickedStorage) {
            val storage = findNode(root) { isStorageNavNode(it) }
            if (storage != null && clickNodeOrAncestor(storage)) {
                clickedStorage = true
            }
        }
    }

    // --- Fluxo ---------------------------------------------------------------

    private fun openCurrent() {
        val items = CleanSession.queue
        if (index !in items.indices) return
        val (pkg, label) = items[index]
        advanceGuard = -1
        clickedStorage = false
        CleanSession.update(index, label)
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.fromParts("package", pkg, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            scheduleStep(PER_APP_TIMEOUT_MS) // watchdog: se a tela não casar, segue em frente
        } catch (_: Throwable) {
            scheduleStep(300L)
        }
    }

    /** Agenda o único passo pendente, cancelando qualquer outro. */
    private fun scheduleStep(delay: Long) {
        handler.removeCallbacks(stepRunnable)
        handler.postDelayed(stepRunnable, delay)
    }

    private fun advance() {
        if (advanceGuard == index) return // já avançamos a partir deste índice
        advanceGuard = index
        handler.removeCallbacks(stepRunnable)

        index++
        val items = CleanSession.queue
        if (index < items.size) {
            openCurrent()
        } else {
            CleanSession.update(items.size, "")
            CleanSession.finish()
            returnToApp()
        }
    }

    private fun returnToApp() {
        try {
            packageManager.getLaunchIntentForPackage(packageName)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ?.let { startActivity(it) }
        } catch (_: Throwable) { /* ignore */ }
    }

    // --- Casamento de nós ----------------------------------------------------

    private fun nodeText(node: AccessibilityNodeInfo): String =
        (node.text?.toString() ?: node.contentDescription?.toString() ?: "")
            .lowercase()
            .trim()

    /** Botão "Limpar cache"/"Clear cache" — e NUNCA limpar dados/armazenamento. */
    private fun isClearCacheNode(node: AccessibilityNodeInfo): Boolean {
        val t = nodeText(node)
        if (t.isEmpty() || !t.contains("cache")) return false
        val isClearWord = t.contains("limpar") || t.contains("clear") || t.contains("apagar")
        val isDangerous = t.contains("dados") || t.contains("data") ||
            t.contains("armazenamento") || t.contains("storage")
        return isClearWord && !isDangerous
    }

    /** Linha "Armazenamento e cache"/"Storage & cache" na tela de informações do app. */
    private fun isStorageNavNode(node: AccessibilityNodeInfo): Boolean {
        val t = nodeText(node)
        if (t.isEmpty()) return false
        val isStorage = t.contains("armazenamento") || t.contains("storage")
        val isClearButton = t.contains("limpar") || t.contains("clear")
        return isStorage && !isClearButton
    }

    private fun findNode(
        root: AccessibilityNodeInfo?,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (root == null) return null
        if (predicate(root)) return root
        for (i in 0 until root.childCount) {
            val found = findNode(root.getChild(i), predicate)
            if (found != null) return found
        }
        return null
    }

    /** Clica no nó ou no ancestral clicável mais próximo que esteja habilitado. */
    private fun clickNodeOrAncestor(node: AccessibilityNodeInfo?): Boolean {
        var n = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.isEnabled) {
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            n = n.parent
            depth++
        }
        return false
    }

    companion object {
        private const val PER_APP_TIMEOUT_MS = 3500L
        private const val AFTER_CLEAR_MS = 600L

        @Volatile
        var INSTANCE: CacheCleanAccessibilityService? = null
            private set

        fun isConnected(): Boolean = INSTANCE != null

        /** Ponto de entrada da UI. Retorna false se o serviço não está ativo. */
        fun beginClean(items: List<Pair<String, String>>): Boolean {
            val svc = INSTANCE ?: return false
            svc.startClean(items)
            return true
        }

        fun cancelClean() { INSTANCE?.cancel() }
    }
}
