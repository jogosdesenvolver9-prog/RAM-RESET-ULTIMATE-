package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.RamLineChart
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard

@Composable
fun RamMonitorScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    DisposableEffect(Unit) {
        viewModel.startMonitoring()
        onDispose { viewModel.stopMonitoring() }
    }
    val mem = state.memory

    ScreenScaffold(title = "RAM Monitor", subtitle = "Histórico real, atualizado a cada 2s") {
        SectionCard(title = "Uso de memória (%)") {
            RamLineChart(data = state.ramHistoryPercent, modifier = Modifier.padding(top = 8.dp))
        }

        SectionCard(title = "Valores atuais") {
            InfoRow("RAM total", Formatters.bytes(mem?.totalBytes ?: -1))
            InfoRow("RAM disponível", Formatters.bytes(mem?.availableBytes ?: -1))
            InfoRow("RAM usada (estimada)", Formatters.bytes(mem?.usedBytes ?: -1))
            InfoRow("Percentual de uso", Formatters.percent(mem?.usedPercent ?: 0))
            InfoRow("Limiar de baixa memória", Formatters.bytes(mem?.thresholdBytes ?: -1))
            InfoRow("Estado de baixa memória", if (mem?.lowMemory == true) "SIM" else "Não")
        }

        SectionCard(title = "Consumo do próprio RAM Reset") {
            InfoRow("PSS do app", Formatters.bytes(mem?.appPssBytes ?: -1))
            Text(
                "PSS (Proportional Set Size) é a parcela de RAM atribuída a este app, " +
                    "incluindo a fatia proporcional de memória compartilhada.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}
