package com.kaikodev.ramreset

import android.app.Application

/**
 * Classe Application. Mantida propositalmente mínima:
 * nenhum serviço persistente, nenhum trabalho pesado no onCreate.
 * (Requisito seção 11: baixo consumo do próprio app.)
 */
class RamResetApp : Application()
