package com.kaikodev.ramreset.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.kaikodev.ramreset.core.AppAnalyzer
import com.kaikodev.ramreset.core.MemoryAnalyzer
import com.kaikodev.ramreset.core.MemoryPressureDetector
import com.kaikodev.ramreset.core.PerformanceTuner
import com.kaikodev.ramreset.core.ResetEngine
import com.kaikodev.ramreset.core.StorageAnalyzer
import com.kaikodev.ramreset.core.SystemDiagnostics
import com.kaikodev.ramreset.core.UsageAnalyzer
import com.kaikodev.ramreset.core.ZramReader
import com.kaikodev.ramreset.core.accessibility.CacheCleanAccessibilityService
import com.kaikodev.ramreset.core.model.UsageApp
import com.kaikodev.ramreset.core.model.AppInfo
import com.kaikodev.ramreset.core.model.MemorySnapshot
import com.kaikodev.ramreset.core.model.PressureResult
import com.kaikodev.ramreset.core.model.ResetReport
import com.kaikodev.ramreset.core.model.StorageInfo
import com.kaikodev.ramreset.core.model.SystemInfo
import com.kaikodev.ramreset.core.model.ZramInfo
import com.kaikodev.ramreset.data.HistoryEntry
import com.kaikodev.ramreset.data.HistoryRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Estado único da UI (StateFlow — seção 11). Imutável; atualizado via copy().
 */
data class RamResetUiState(
    val memory: MemorySnapshot? = null,
    val pressure: PressureResult? = null,
    val zram: ZramInfo? = null,
    val storage: StorageInfo? = null,
    val system: SystemInfo? = null,
    val apps: List<AppInfo> = emptyList(),
    val appsLoading: Boolean = false,
    val ramHistoryPercent: List<Int> = emptyList(), // histórico REAL de uso% (seção 5)
    val lastReport: ResetReport? = null,
    val isResetting: Boolean = false,
    val history: List<HistoryEntry> = emptyList(),
    // Boost / apps em segundo plano
    val usageApps: List<UsageApp> = emptyList(),
    val usageLoading: Boolean = false,
    val hasUsageAccess: Boolean = false,
    // Desempenho / anti-lag
    val animationAverage: Float = 1f,
    val lagHint: String = ""
)

class MainViewModel(context: Context) : ViewModel() {

    private val appContext = context.applicationContext
    private val memoryAnalyzer = MemoryAnalyzer(appContext)
    private val storageAnalyzer = StorageAnalyzer(appContext)
    private val systemDiagnostics = SystemDiagnostics(appContext)
    private val zramReader = ZramReader()
    private val appAnalyzer = AppAnalyzer(appContext)
    private val usageAnalyzer = UsageAnalyzer(appContext)
    private val performanceTuner = PerformanceTuner(appContext)
    private val resetEngine = ResetEngine(appContext)
    private val historyRepo = HistoryRepository(appContext)

    private val _state = MutableStateFlow(RamResetUiState())
    val state: StateFlow<RamResetUiState> = _state.asStateFlow()

    private var monitorJob: Job? = null

    companion object {
        private const val HISTORY_CAP = 40        // pontos no gráfico
        private const val REFRESH_INTERVAL_MS = 2000L

        fun factory(context: Context): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    MainViewModel(context) as T
            }
    }

    init {
        // Carrega o histórico persistido de forma reativa.
        historyRepo.history
            .onEach { entries -> _state.update { it.copy(history = entries) } }
            .launchIn(viewModelScope)

        // Primeira leitura imediata (dados estáticos + memória).
        refreshStatic()
        refreshMemory()
    }

    /** Dados que mudam pouco: sistema, armazenamento, ZRAM. */
    fun refreshStatic() {
        viewModelScope.launch {
            val sys = runCatching { systemDiagnostics.read() }.getOrNull()
            val sto = runCatching { storageAnalyzer.read() }.getOrNull()
            val z = runCatching { zramReader.read() }.getOrNull()
            _state.update { it.copy(system = sys, storage = sto, zram = z) }
        }
    }

    /** Leitura de memória + pressão; acrescenta ponto ao histórico do gráfico. */
    fun refreshMemory() {
        val snap = memoryAnalyzer.snapshot()
        val pressure = MemoryPressureDetector.evaluate(snap)
        _state.update { s ->
            val newHistory = (s.ramHistoryPercent + snap.usedPercent).takeLast(HISTORY_CAP)
            s.copy(memory = snap, pressure = pressure, ramHistoryPercent = newHistory)
        }
    }

    /** Monitoramento contínuo e adaptativo (seção 11: eficiente, cancelável). */
    fun startMonitoring() {
        if (monitorJob?.isActive == true) return
        monitorJob = viewModelScope.launch {
            while (isActive) {
                refreshMemory()
                kotlinx.coroutines.delay(REFRESH_INTERVAL_MS)
            }
        }
    }

    fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
    }

    fun loadApps(includeSystem: Boolean = false) {
        if (_state.value.appsLoading) return
        _state.update { it.copy(appsLoading = true) }
        viewModelScope.launch {
            val list = runCatching { appAnalyzer.installedApps(includeSystem) }.getOrDefault(emptyList())
            _state.update { it.copy(apps = list, appsLoading = false) }
        }
    }

    /** Executa o Reset Engine (operações reais) e persiste o relatório. */
    fun runReset() {
        if (_state.value.isResetting) return
        _state.update { it.copy(isResetting = true) }
        viewModelScope.launch {
            val report = resetEngine.run()
            historyRepo.add(report)
            refreshStatic() // cache do app mudou → atualiza armazenamento
            _state.update { it.copy(lastReport = report, isResetting = false) }
        }
    }

    fun clearHistory() {
        viewModelScope.launch { historyRepo.clear() }
    }

    // --- Boost: apps usados recentemente -------------------------------------

    fun loadUsageApps() {
        _state.update { it.copy(usageLoading = true) }
        viewModelScope.launch {
            val access = usageAnalyzer.hasUsageAccess()
            val apps = if (access) runCatching { usageAnalyzer.recentApps() }.getOrDefault(emptyList())
            else emptyList()
            _state.update { it.copy(usageApps = apps, hasUsageAccess = access, usageLoading = false) }
        }
    }

    // --- Desempenho / anti-lag -----------------------------------------------

    fun refreshPerformance() {
        val scales = performanceTuner.readAnimationScales()
        _state.update {
            it.copy(animationAverage = scales.average, lagHint = performanceTuner.lagHint(scales))
        }
    }

    // --- Deep Clean: cache de todos os apps (via acessibilidade) --------------

    /**
     * Monta a lista de apps do usuário e inicia a limpeza automatizada.
     * Retorna false se o serviço de acessibilidade não estiver ativo.
     */
    fun startDeepClean(): Boolean {
        val apps = runCatching { appAnalyzer.installedApps(includeSystem = false) }
            .getOrDefault(emptyList())
            .filter { !it.isOwn }
            .map { it.packageName to it.label }
        if (apps.isEmpty()) return false
        return CacheCleanAccessibilityService.beginClean(apps)
    }

    fun cancelDeepClean() = CacheCleanAccessibilityService.cancelClean()

    override fun onCleared() {
        super.onCleared()
        stopMonitoring()
    }
}
