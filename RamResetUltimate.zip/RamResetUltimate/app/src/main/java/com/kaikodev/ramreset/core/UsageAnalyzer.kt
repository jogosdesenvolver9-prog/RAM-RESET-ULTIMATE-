package com.kaikodev.ramreset.core

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import com.kaikodev.ramreset.core.model.UsageApp

/**
 * Identifica apps usados recentemente via UsageStatsManager (seções 7/8).
 *
 * HONESTO: o Android NÃO deixa um app comum listar processos de terceiros em segundo plano
 * nem o quanto de RAM cada um usa. O que dá para saber, COM a permissão "Acesso ao uso"
 * (que o usuário concede manualmente), é quais apps foram usados recentemente — bons
 * candidatos a fechar. Fechar em si é feito pelo usuário na tela oficial (Forçar parada).
 */
class UsageAnalyzer(context: Context) {

    private val appContext = context.applicationContext
    private val pm: PackageManager = appContext.packageManager
    private val ownPackage = appContext.packageName

    /** Verifica se a permissão "Acesso ao uso" foi concedida. */
    fun hasUsageAccess(): Boolean {
        return try {
            val appOps = appContext.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ownPackage
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ownPackage
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Apps usados nas últimas [windowMs] (padrão 3h), mais recentes primeiro.
     * Exclui o próprio app. Retorna lista vazia sem a permissão.
     */
    fun recentApps(windowMs: Long = 3 * 60 * 60 * 1000L, limit: Int = 30): List<UsageApp> {
        if (!hasUsageAccess()) return emptyList()
        val usm = appContext.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return emptyList()

        val end = System.currentTimeMillis()
        val start = end - windowMs

        val stats = try {
            usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)
        } catch (_: Throwable) {
            emptyList()
        } ?: emptyList()

        return stats.asSequence()
            .filter { it.packageName != ownPackage }
            .filter { it.lastTimeUsed in start..end }
            .filter { it.totalTimeInForeground > 0 }
            .distinctBy { it.packageName }
            .sortedByDescending { it.lastTimeUsed }
            .take(limit)
            .mapNotNull { s ->
                val label = labelFor(s.packageName) ?: return@mapNotNull null
                UsageApp(
                    packageName = s.packageName,
                    label = label,
                    lastUsedMs = s.lastTimeUsed,
                    foregroundTimeMs = s.totalTimeInForeground
                )
            }
            .toList()
    }

    private fun labelFor(pkg: String): String? = try {
        val info = pm.getApplicationInfo(pkg, 0)
        pm.getApplicationLabel(info).toString()
    } catch (_: Throwable) {
        null // app não visível / desinstalado
    }
}
