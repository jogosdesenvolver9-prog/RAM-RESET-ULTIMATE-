package com.kaikodev.ramreset.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import com.kaikodev.ramreset.core.model.SystemInfo

/** Diagnóstico do dispositivo (seção 7). Tudo via APIs públicas, sem permissões especiais. */
class SystemDiagnostics(context: Context) {

    private val appContext = context.applicationContext
    private val activityManager =
        appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun read(): SystemInfo {
        val battery = readBattery()
        return SystemInfo(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            androidRelease = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            batteryPercent = battery?.percent,
            batteryCharging = battery?.charging,
            batteryTemperatureC = battery?.temperatureC,
            batteryHealth = battery?.health,
            uptimeMs = SystemClock.elapsedRealtime(),
            ramClassMb = activityManager.memoryClass
        )
    }

    private data class Battery(
        val percent: Int?,
        val charging: Boolean?,
        val temperatureC: Float?,
        val health: String?
    )

    private fun readBattery(): Battery? {
        // Intent "sticky": passar null como receiver devolve o último estado da bateria.
        val intent: Intent = appContext.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return null

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) (level * 100) / scale else null

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING,
            BatteryManager.BATTERY_STATUS_FULL -> true
            BatteryManager.BATTERY_STATUS_DISCHARGING,
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> false
            else -> null
        }

        // EXTRA_TEMPERATURE vem em décimos de °C (ex.: 312 = 31,2 °C). É a bateria, não a CPU.
        val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temperatureC = if (tempRaw != Int.MIN_VALUE) tempRaw / 10f else null

        val health = when (intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Boa"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Superaquecida"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Danificada"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Sobretensão"
            BatteryManager.BATTERY_HEALTH_COLD -> "Fria"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Falha"
            else -> null
        }

        return Battery(percent, charging, temperatureC, health)
    }
}
