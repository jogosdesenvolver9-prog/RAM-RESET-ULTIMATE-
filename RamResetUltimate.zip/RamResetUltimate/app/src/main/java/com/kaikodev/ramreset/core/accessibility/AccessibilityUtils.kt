package com.kaikodev.ramreset.core.accessibility

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils

/** Helpers para checar e abrir as configurações de acessibilidade. */
object AccessibilityUtils {

    private const val SERVICE_ID_SUFFIX =
        "com.kaikodev.ramreset/com.kaikodev.ramreset.core.accessibility.CacheCleanAccessibilityService"

    /**
     * Verifica se o nosso serviço está habilitado nas configurações do sistema.
     * Lê Settings.Secure (sem permissão especial — apenas leitura).
     */
    fun isServiceEnabled(context: Context): Boolean {
        val enabled = try {
            Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
        } catch (_: Throwable) {
            null
        } ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        for (component in splitter) {
            if (component.endsWith(SERVICE_ID_SUFFIX) ||
                component.contains("CacheCleanAccessibilityService")
            ) return true
        }
        return false
    }

    /** True quando dá para limpar: serviço habilitado nas configs E conectado no processo. */
    fun isReady(context: Context): Boolean =
        isServiceEnabled(context) && CacheCleanAccessibilityService.isConnected()

    fun openAccessibilitySettings(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Throwable) { /* ignore */ }
    }
}
