package com.kaikodev.ramreset.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Atalhos para telas NATIVAS do Android (seções 5 / 7 / 9).
 * O app não "faz a limpeza pesada" — ele leva o usuário até a tela oficial onde o
 * PRÓPRIO sistema faz, que é o caminho correto e seguro sem root.
 */
object SystemShortcuts {

    private fun start(context: Context, intent: Intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Throwable) {
            // Algumas OEMs não expõem certas telas; falha silenciosa evita crash.
        }
    }

    /** Tela de informações de um app específico (onde o usuário pode Forçar Parada / Limpar Cache). */
    fun openAppDetails(context: Context, packageName: String) {
        start(context, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        })
    }

    /** Lista de todos os apps. */
    fun openAppsList(context: Context) =
        start(context, Intent(Settings.ACTION_APPLICATION_SETTINGS))

    /** Gerenciamento de armazenamento do Android. */
    fun openStorageSettings(context: Context) =
        start(context, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))

    /** Otimização de bateria. */
    fun openBatterySettings(context: Context) =
        start(context, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))

    /** Opções do desenvolvedor (perfis de desempenho, limites de processos em background). */
    fun openDeveloperSettings(context: Context) =
        start(context, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))

    /** Tela de "Acesso ao uso", necessária para estatísticas de uso por app (opcional). */
    fun openUsageAccessSettings(context: Context) =
        start(context, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    /** Configurações gerais, como fallback. */
    fun openSettings(context: Context) =
        start(context, Intent(Settings.ACTION_SETTINGS))
}
