package com.kaikodev.ramreset.core.model

/**
 * Estado de memória comprimida / swap (seção 4).
 * Diferencia claramente RAM física, swap e ZRAM.
 * Campos -1 significam "não acessível neste dispositivo/versão".
 */
data class ZramInfo(
    val zramDetected: Boolean,
    val swapTotalBytes: Long,     // MemTotal de swap (/proc/meminfo SwapTotal)
    val swapFreeBytes: Long,      // SwapFree
    val zramDataBytes: Long,      // dados originais (mm_stat col 0), -1 se indisponível
    val zramCompressedBytes: Long,// tamanho comprimido (mm_stat col 1), -1 se indisponível
    val readLimited: Boolean,     // true se não conseguimos ler arquivos privilegiados
    val note: String
) {
    val swapUsedBytes: Long
        get() = if (swapTotalBytes >= 0 && swapFreeBytes >= 0)
            (swapTotalBytes - swapFreeBytes).coerceAtLeast(0L) else -1L

    /** Razão de compressão (dados / comprimido). Null se não mensurável. */
    val compressionRatio: Double?
        get() = if (zramDataBytes > 0 && zramCompressedBytes > 0)
            zramDataBytes.toDouble() / zramCompressedBytes.toDouble() else null
}
