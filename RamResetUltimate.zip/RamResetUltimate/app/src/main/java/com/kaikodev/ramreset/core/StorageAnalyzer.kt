package com.kaikodev.ramreset.core

import android.content.Context
import android.os.Environment
import android.os.StatFs
import com.kaikodev.ramreset.core.model.StorageInfo
import java.io.File

/** Armazenamento interno + cache do próprio app (seção 9). */
class StorageAnalyzer(context: Context) {

    private val appContext = context.applicationContext

    fun read(): StorageInfo {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.blockCountLong * stat.blockSizeLong
        val available = stat.availableBlocksLong * stat.blockSizeLong

        return StorageInfo(
            totalBytes = total,
            availableBytes = available,
            ownCacheBytes = ownCacheSize()
        )
    }

    /** Soma o tamanho do cache interno + externo do PRÓPRIO app. */
    fun ownCacheSize(): Long {
        var sum = dirSize(appContext.cacheDir)
        appContext.externalCacheDir?.let { sum += dirSize(it) }
        return sum
    }

    private fun dirSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        return try {
            dir.walkBottomUp().filter { it.isFile }.map { it.length() }.sum()
        } catch (_: Throwable) {
            0L
        }
    }
}
