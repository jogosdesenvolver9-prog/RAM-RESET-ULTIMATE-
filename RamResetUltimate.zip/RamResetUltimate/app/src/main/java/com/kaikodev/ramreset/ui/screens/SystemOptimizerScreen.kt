package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.SystemShortcuts
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard

@Composable
fun SystemOptimizerScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val sys = state.system

    ScreenScaffold(
        title = "Smart Optimizer",
        subtitle = "Diagnóstico + atalhos oficiais do Android"
    ) {
        SectionCard(title = "Dispositivo") {
            InfoRow("Fabricante", sys?.manufacturer ?: "—")
            InfoRow("Modelo", sys?.model ?: "—")
            InfoRow("Android", sys?.androidRelease?.let { "$it (API ${sys.sdkInt})" } ?: "—")
            InfoRow("Núcleos de CPU", sys?.cpuCores?.toString() ?: "—")
            InfoRow("Classe de heap por app", sys?.ramClassMb?.let { "$it MB" } ?: "—")
            InfoRow("Tempo ligado", sys?.uptimeMs?.let { formatUptime(it) } ?: "—")
        }

        SectionCard(title = "Bateria") {
            InfoRow("Nível", sys?.batteryPercent?.let { "$it%" } ?: "—")
            InfoRow("Carregando", when (sys?.batteryCharging) { true -> "Sim"; false -> "Não"; null -> "—" })
            InfoRow("Temperatura", sys?.batteryTemperatureC?.let { String.format("%.1f °C", it) } ?: "—")
            InfoRow("Saúde", sys?.batteryHealth ?: "—")
        }

        SectionCard(title = "Armazenamento") {
            InfoRow("Total", Formatters.bytes(state.storage?.totalBytes ?: -1))
            InfoRow("Disponível", Formatters.bytes(state.storage?.availableBytes ?: -1))
            InfoRow("Usado", Formatters.bytes(state.storage?.usedBytes ?: -1))
        }

        SectionCard(title = "Atalhos do sistema") {
            Text(
                "A limpeza pesada é feita pelo próprio Android. Estes atalhos levam você às telas oficiais:",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            ShortcutButton("Apps instalados") { SystemShortcuts.openAppsList(context) }
            ShortcutButton("Armazenamento") { SystemShortcuts.openStorageSettings(context) }
            ShortcutButton("Economia de bateria") { SystemShortcuts.openBatterySettings(context) }
            ShortcutButton("Opções do desenvolvedor") { SystemShortcuts.openDeveloperSettings(context) }
        }
    }
}

@Composable
private fun ShortcutButton(text: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(text) }
}

private fun formatUptime(ms: Long): String {
    val totalMin = ms / 60000
    val h = totalMin / 60
    val m = totalMin % 60
    return "${h}h ${m}min"
}
