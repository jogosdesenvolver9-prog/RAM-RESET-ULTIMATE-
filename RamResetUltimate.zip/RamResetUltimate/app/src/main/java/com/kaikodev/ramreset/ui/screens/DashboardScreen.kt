package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.CircularGauge
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.PressureBadge
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard
import com.kaikodev.ramreset.ui.components.StatTile
import com.kaikodev.ramreset.ui.navigation.Routes
import com.kaikodev.ramreset.ui.theme.NeonPurple

@Composable
fun DashboardScreen(viewModel: MainViewModel, nav: NavController) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    // Monitora enquanto a tela está viva; cancela ao sair (seção 11).
    DisposableEffect(Unit) {
        viewModel.startMonitoring()
        onDispose { viewModel.stopMonitoring() }
    }

    val mem = state.memory

    ScreenScaffold(
        title = "RAM Reset Ultimate",
        subtitle = state.system?.let { "${it.manufacturer} ${it.model} · Android ${it.androidRelease}" }
    ) {
        SectionCard {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularGauge(
                    percent = mem?.usedPercent ?: 0,
                    label = "RAM em uso"
                )
            }
            androidx.compose.foundation.layout.Spacer(Modifier.padding(6.dp))
            state.pressure?.let {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    PressureBadge(it.level, it.estimated)
                }
            }
        }

        // Grade de estatísticas reais.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                "Disponível",
                Formatters.bytes(mem?.availableBytes ?: -1),
                Modifier.weight(1f)
            )
            StatTile(
                "Total",
                Formatters.bytes(mem?.totalBytes ?: -1),
                Modifier.weight(1f)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                "Uso do app",
                Formatters.bytes(mem?.appPssBytes ?: -1),
                Modifier.weight(1f)
            )
            StatTile(
                "Bateria",
                state.system?.batteryPercent?.let { "$it%" } ?: "—",
                Modifier.weight(1f)
            )
        }

        Button(
            onClick = { nav.navigate(Routes.RESET) },
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
        ) {
            Text("Executar Reset Engine", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { nav.navigate(Routes.DEEP_CLEAN) }, modifier = Modifier.weight(1f)) {
                Text("Limpar tudo")
            }
            OutlinedButton(onClick = { nav.navigate(Routes.BOOST) }, modifier = Modifier.weight(1f)) {
                Text("Boost")
            }
        }

        SectionCard(title = "Resumo do sistema") {
            InfoRow("RAM disponível", Formatters.bytes(mem?.availableBytes ?: -1))
            InfoRow("RAM usada (estimada)", Formatters.bytes(mem?.usedBytes ?: -1))
            InfoRow("Estado de baixa memória", if (mem?.lowMemory == true) "SIM" else "Não")
            InfoRow("Armazenamento livre", Formatters.bytes(state.storage?.availableBytes ?: -1))
            InfoRow("ZRAM/Swap", if (state.zram?.zramDetected == true) "Detectado" else "Não detectado")
        }

        Text(
            "Os números vêm direto das APIs do Android. Nenhum valor é simulado.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )
    }
}
