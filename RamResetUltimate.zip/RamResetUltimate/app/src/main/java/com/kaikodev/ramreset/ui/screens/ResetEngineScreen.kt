package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.model.ResetReport
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard
import com.kaikodev.ramreset.ui.components.StatTile
import com.kaikodev.ramreset.ui.theme.ElectricBlue
import com.kaikodev.ramreset.ui.theme.NeonPurple
import com.kaikodev.ramreset.ui.theme.StateNormal

@Composable
fun ResetEngineScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    ScreenScaffold(
        title = "Reset Engine",
        subtitle = "Operações reais no próprio app + diagnóstico honesto"
    ) {
        SectionCard {
            Text(
                "O Reset Engine libera recursos do PRÓPRIO app (cache, buffers, coleta de lixo) " +
                    "e mede RAM antes/depois. Ele NÃO encerra outros apps nem aumenta a RAM física — " +
                    "isso é impossível sem root, e o relatório abaixo deixa isso explícito.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = { viewModel.runReset() },
                enabled = !state.isResetting,
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
            ) {
                if (state.isResetting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                    Text("  Otimizando…", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("INICIAR OTIMIZAÇÃO", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }

        state.lastReport?.let { report -> ReportView(report) }
    }
}

@Composable
private fun ReportView(report: ResetReport) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatTile("RAM livre antes", Formatters.bytes(report.before.availableBytes), Modifier.weight(1f))
        StatTile("RAM livre depois", Formatters.bytes(report.after.availableBytes), Modifier.weight(1f))
    }

    SectionCard(title = "Resultado medido") {
        InfoRow("Cache do app liberado", Formatters.bytes(report.ownCacheFreedBytes))
        InfoRow("Variação do PSS do app", Formatters.signedBytes(report.ownPssDeltaBytes))
        InfoRow("Ganho comprovado (app)", Formatters.bytes(report.provenFreedBytes))
        InfoRow("Variação de RAM do sistema", Formatters.signedBytes(report.systemAvailableDeltaBytes))
        Text(
            "A variação do sistema é apenas observada: o Android move memória o tempo todo, " +
                "então ela não é creditada como mérito garantido do app (seção 12 do spec).",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp)
        )
    }

    SectionCard(title = "Operações executadas") {
        report.operationsDone.forEach { op ->
            Text("✓ $op", style = MaterialTheme.typography.bodyMedium, color = StateNormal, modifier = Modifier.padding(vertical = 3.dp))
        }
    }

    SectionCard(title = "Operações indisponíveis (sem root)") {
        report.operationsUnavailable.forEach { op ->
            Text("✕ $op", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 3.dp))
        }
    }

    if (report.recommendations.isNotEmpty()) {
        SectionCard(title = "Recomendações") {
            report.recommendations.forEach { rec ->
                Text("• $rec", style = MaterialTheme.typography.bodyMedium, color = ElectricBlue, modifier = Modifier.padding(vertical = 3.dp))
            }
        }
    }
}
