package com.kaikodev.ramreset.core.model

/** App usado recentemente (candidato a consumir recursos em segundo plano — seção 7/8). */
data class UsageApp(
    val packageName: String,
    val label: String,
    val lastUsedMs: Long,
    val foregroundTimeMs: Long
)
