package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.SystemShortcuts
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.PressureBadge
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard

@Composable
fun GameBoosterScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Monitora, mas de forma leve (o próprio intervalo de 2s é econômico — seção 8/11).
    DisposableEffect(Unit) {
        viewModel.startMonitoring()
        onDispose { viewModel.stopMonitoring() }
    }
    val mem = state.memory

    ScreenScaffold(title = "Game Booster", subtitle = "Monitoramento leve antes e durante jogos") {
        SectionCard(title = "Prontidão para jogar") {
            state.pressure?.let {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    PressureBadge(it.level, it.estimated)
                }
            }
            InfoRow("RAM disponível", Formatters.bytes(mem?.availableBytes ?: -1))
            InfoRow("RAM em uso", Formatters.percent(mem?.usedPercent ?: 0))
            InfoRow("Consumo deste app", Formatters.bytes(mem?.appPssBytes ?: -1))
        }

        SectionCard(title = "Antes de abrir o jogo") {
            Text(
                recommendationFor(mem?.usedPercent ?: 0),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard(title = "Atalhos úteis") {
            OutlinedButton(onClick = { SystemShortcuts.openBatterySettings(context) }, modifier = Modifier.fillMaxWidth()) {
                Text("Desempenho / Bateria")
            }
            OutlinedButton(onClick = { SystemShortcuts.openAppsList(context) }, modifier = Modifier.fillMaxWidth()) {
                Text("Fechar apps em segundo plano")
            }
        }

        SectionCard(title = "Honestidade") {
            Text(
                "Este modo NÃO aumenta FPS artificialmente. Ele apenas monitora a memória e sugere " +
                    "liberar recursos antes de jogar. O RAM Reset usa monitoramento leve para não " +
                    "atrapalhar o desempenho do jogo.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun recommendationFor(usedPercent: Int): String = when {
    usedPercent >= 85 -> "Memória bem ocupada. Feche apps pesados ou reinicie o aparelho antes de jogar para uma experiência mais fluida."
    usedPercent >= 70 -> "Uso moderado. Feche um ou dois apps em segundo plano se o jogo for exigente."
    else -> "Memória tranquila. Bom momento para jogar."
}
