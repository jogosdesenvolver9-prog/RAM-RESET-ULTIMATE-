package com.kaikodev.ramreset.core.model

/** Armazenamento interno + cache do próprio app (seção 9). */
data class StorageInfo(
    val totalBytes: Long,
    val availableBytes: Long,
    val ownCacheBytes: Long       // cacheDir + externalCacheDir do próprio app
) {
    val usedBytes: Long get() = (totalBytes - availableBytes).coerceAtLeast(0L)
    val usedPercent: Int
        get() = if (totalBytes <= 0L) 0
        else ((usedBytes.toDouble() / totalBytes.toDouble()) * 100.0).toInt().coerceIn(0, 100)
}
