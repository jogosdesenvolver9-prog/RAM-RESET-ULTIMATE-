package com.kaikodev.ramreset.core

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.kaikodev.ramreset.core.model.AppInfo

/**
 * Lista apps instalados VISÍVEIS (seção 5), respeitando a visibilidade de pacotes
 * do Android 11+. Não usamos QUERY_ALL_PACKAGES. Não inventamos consumo por app.
 */
class AppAnalyzer(context: Context) {

    private val appContext = context.applicationContext
    private val pm: PackageManager = appContext.packageManager
    private val ownPackage = appContext.packageName

    fun installedApps(includeSystem: Boolean = false): List<AppInfo> {
        val apps = try {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        } catch (_: Throwable) {
            emptyList()
        }

        return apps.asSequence()
            .map { info ->
                val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                AppInfo(
                    packageName = info.packageName,
                    label = runCatching { pm.getApplicationLabel(info).toString() }
                        .getOrDefault(info.packageName),
                    isSystem = isSystem,
                    isOwn = info.packageName == ownPackage
                )
            }
            .filter { includeSystem || !it.isSystem || it.isOwn }
            .sortedBy { it.label.lowercase() }
            .toList()
    }
}
