package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.accessibility.AccessibilityUtils
import com.kaikodev.ramreset.core.accessibility.CleanSession
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard
import com.kaikodev.ramreset.ui.theme.ElectricBlue
import com.kaikodev.ramreset.ui.theme.NeonPurple
import com.kaikodev.ramreset.ui.theme.StateNormal

@Composable
fun DeepCleanScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val progress by CleanSession.progress.collectAsStateWithLifecycle()

    var enabled by remember { mutableStateOf(AccessibilityUtils.isServiceEnabled(context)) }
    // Reavalia quando o usuário volta das configurações de acessibilidade.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        enabled = AccessibilityUtils.isServiceEnabled(context)
    }

    ScreenScaffold(
        title = "Limpeza Profunda",
        subtitle = "Limpa o cache de TODOS os apps automaticamente"
    ) {
        SectionCard {
            Text(
                "Esta função usa o serviço de acessibilidade para abrir as configurações de cada " +
                    "app e tocar em \"Limpar cache\" por você — o próprio Android apaga o cache. " +
                    "É a forma real de limpar o cache de todos os apps sem root.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        when {
            progress.active -> RunningView(progress) { viewModel.cancelDeepClean() }

            !enabled -> SectionCard(title = "1 passo para ativar") {
                Text(
                    "Ative o serviço \"RAM Reset — Limpeza de cache\" na tela de acessibilidade. " +
                        "Ele só age quando você inicia uma limpeza e nunca toca em \"Limpar dados\".",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { AccessibilityUtils.openAccessibilitySettings(context) },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                ) { Text("Abrir acessibilidade", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
            }

            else -> {
                if (progress.finished) SectionCard(title = "Concluído") {
                    Text(
                        "${progress.processed} apps processados. O cache foi limpo pelo Android.",
                        style = MaterialTheme.typography.titleMedium,
                        color = StateNormal
                    )
                }
                SectionCard {
                    Button(
                        onClick = { viewModel.startDeepClean() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                    ) { Text("LIMPAR CACHE DE TODOS OS APPS", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
                    Text(
                        "Durante a limpeza, o app controla a tela sozinho. Não mexa no aparelho até terminar.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
        }

        SectionCard(title = "Honestidade") {
            Text(
                "O cache volta a crescer com o uso normal — isso é esperado. Limpar cache libera " +
                    "armazenamento e pode remover travamentos pontuais, mas não é um ganho permanente " +
                    "nem acelera magicamente o aparelho. Nada é inventado.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun RunningView(progress: CleanSession.Progress, onStop: () -> Unit) {
    SectionCard(title = "Limpando…") {
        val fraction = if (progress.total > 0) progress.processed.toFloat() / progress.total else 0f
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            color = ElectricBlue
        )
        Text(
            "${progress.processed}/${progress.total} · ${progress.currentLabel}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        OutlinedButton(
            onClick = onStop,
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        ) { Text("Parar") }
    }
}
