package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.data.HistoryEntry
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.ScreenScaffoldLazy
import com.kaikodev.ramreset.ui.theme.Surface1
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    ScreenScaffoldLazy(
        title = "Histórico",
        subtitle = "${state.history.size} otimizações registradas"
    ) {
        if (state.history.isEmpty()) {
            item {
                Text(
                    "Nenhuma otimização ainda. Rode o Reset Engine para começar o histórico.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            item {
                OutlinedButton(
                    onClick = { viewModel.clearHistory() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Limpar histórico") }
            }
            items(state.history, key = { it.timestampMs }) { entry -> HistoryCard(entry) }
        }
    }
}

@Composable
private fun HistoryCard(entry: HistoryEntry) {
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Surface1)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                fmt.format(Date(entry.timestampMs)),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            InfoRow("RAM livre antes", Formatters.bytes(entry.availableBeforeBytes))
            InfoRow("RAM livre depois", Formatters.bytes(entry.availableAfterBytes))
            InfoRow("Uso antes → depois", "${entry.usedPercentBefore}% → ${entry.usedPercentAfter}%")
            InfoRow("Cache liberado", Formatters.bytes(entry.ownCacheFreedBytes))
            InfoRow("Ganho comprovado", Formatters.bytes(entry.provenFreedBytes))
        }
    }
}
