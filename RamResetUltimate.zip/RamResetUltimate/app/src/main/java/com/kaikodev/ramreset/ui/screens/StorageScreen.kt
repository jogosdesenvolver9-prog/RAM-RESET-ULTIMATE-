package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.SystemShortcuts
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard

@Composable
fun StorageScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val s = state.storage

    ScreenScaffold(title = "Storage Optimizer", subtitle = "Armazenamento interno e cache do app") {
        SectionCard(title = "Espaço") {
            InfoRow("Total", Formatters.bytes(s?.totalBytes ?: -1))
            InfoRow("Usado", Formatters.bytes(s?.usedBytes ?: -1))
            InfoRow("Disponível", Formatters.bytes(s?.availableBytes ?: -1))
            InfoRow("Uso", Formatters.percent(s?.usedPercent ?: 0))
        }

        SectionCard(title = "Cache do próprio app") {
            InfoRow("Tamanho do cache", Formatters.bytes(s?.ownCacheBytes ?: -1))
            Text(
                "Este é o único cache que o app pode apagar sozinho (no Reset Engine). " +
                    "O cache de outros apps só o Android limpa.",
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard(title = "Gerenciar") {
            OutlinedButton(
                onClick = { SystemShortcuts.openStorageSettings(context) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Abrir gerenciamento de armazenamento") }
        }
    }
}
