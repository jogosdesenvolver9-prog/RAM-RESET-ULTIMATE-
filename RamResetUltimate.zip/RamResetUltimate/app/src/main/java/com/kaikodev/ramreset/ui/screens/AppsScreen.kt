package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.SystemShortcuts
import com.kaikodev.ramreset.core.model.AppInfo
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.ScreenScaffoldLazy
import com.kaikodev.ramreset.ui.theme.NeonPurple
import com.kaikodev.ramreset.ui.theme.Surface1

@Composable
fun AppsScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(Unit) { viewModel.loadApps(includeSystem = false) }

    ScreenScaffoldLazy(
        title = "Análise de apps",
        subtitle = if (state.appsLoading) "Carregando…" else "${state.apps.size} apps visíveis"
    ) {
        item {
            Text(
                "O Android não permite ver o consumo exato de RAM de outros apps sem permissões " +
                    "especiais. Toque em um app para abrir suas configurações e gerenciá-lo (forçar " +
                    "parada, limpar cache) pelo próprio sistema.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(state.apps, key = { it.packageName }) { app ->
            AppRow(app) { SystemShortcuts.openAppDetails(context, app.packageName) }
        }
    }
}

@Composable
private fun AppRow(app: AppInfo, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Surface1)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                app.label + if (app.isOwn) "  (este app)" else "",
                style = MaterialTheme.typography.titleMedium,
                color = if (app.isOwn) NeonPurple else MaterialTheme.colorScheme.onBackground
            )
            Text(
                app.packageName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
