package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.util.Formatters
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard

@Composable
fun ZramScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val z = state.zram

    ScreenScaffold(
        title = "ZRAM Intelligence",
        subtitle = "Memória comprimida e swap — leitura sem root"
    ) {
        SectionCard(title = "Status") {
            InfoRow("ZRAM/Swap detectado", if (z?.zramDetected == true) "Sim" else "Não")
            InfoRow("Leitura limitada", if (z?.readLimited == true) "Sim (sem privilégio)" else "Não")
            Text(
                z?.note ?: "Lendo…",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        SectionCard(title = "Swap (via /proc/meminfo)") {
            InfoRow("Swap total", Formatters.bytes(z?.swapTotalBytes ?: -1))
            InfoRow("Swap livre", Formatters.bytes(z?.swapFreeBytes ?: -1))
            InfoRow("Swap usado", Formatters.bytes(z?.swapUsedBytes ?: -1))
        }

        SectionCard(title = "Compressão ZRAM") {
            InfoRow("Dados originais", Formatters.bytes(z?.zramDataBytes ?: -1))
            InfoRow("Tamanho comprimido", Formatters.bytes(z?.zramCompressedBytes ?: -1))
            InfoRow("Razão de compressão", z?.compressionRatio?.let { String.format("%.2fx", it) } ?: "—")
        }

        SectionCard(title = "Entenda a diferença") {
            Text(
                "RAM física é a memória real do aparelho. ZRAM é uma área de RAM que o kernel " +
                    "comprime para caber mais dados. Swap é espaço que faz papel de memória extra. " +
                    "Nenhum deles pode ser 'resetado' por um app sem root — este módulo é só leitura.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
