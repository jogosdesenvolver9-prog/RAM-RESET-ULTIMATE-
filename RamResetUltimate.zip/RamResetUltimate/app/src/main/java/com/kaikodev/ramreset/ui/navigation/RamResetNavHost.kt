package com.kaikodev.ramreset.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.screens.AppsScreen
import com.kaikodev.ramreset.ui.screens.BoostScreen
import com.kaikodev.ramreset.ui.screens.DashboardScreen
import com.kaikodev.ramreset.ui.screens.DeepCleanScreen
import com.kaikodev.ramreset.ui.screens.GameBoosterScreen
import com.kaikodev.ramreset.ui.screens.HistoryScreen
import com.kaikodev.ramreset.ui.screens.MoreScreen
import com.kaikodev.ramreset.ui.screens.RamMonitorScreen
import com.kaikodev.ramreset.ui.screens.ResetEngineScreen
import com.kaikodev.ramreset.ui.screens.SettingsScreen
import com.kaikodev.ramreset.ui.screens.SplashScreen
import com.kaikodev.ramreset.ui.screens.StorageScreen
import com.kaikodev.ramreset.ui.screens.SystemOptimizerScreen
import com.kaikodev.ramreset.ui.screens.ZramScreen
import com.kaikodev.ramreset.ui.theme.NeonPurple
import com.kaikodev.ramreset.ui.theme.Surface1

@Composable
fun RamResetNavHost(viewModel: MainViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBar = currentRoute != null && currentRoute != Routes.SPLASH

    Scaffold(
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = Surface1) {
                    BottomItem.entries.forEach { item ->
                        val selected = currentRoute == item.route ||
                            (item == BottomItem.MORE && currentRoute in secondaryRoutes)
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    nav.navigate(item.route) {
                                        popUpTo(Routes.DASHBOARD) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonPurple,
                                selectedTextColor = NeonPurple,
                                indicatorColor = NeonPurple.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.SPLASH,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(onFinished = {
                    nav.navigate(Routes.DASHBOARD) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                })
            }
            composable(Routes.DASHBOARD) { DashboardScreen(viewModel, nav) }
            composable(Routes.MONITOR) { RamMonitorScreen(viewModel) }
            composable(Routes.RESET) { ResetEngineScreen(viewModel) }
            composable(Routes.OPTIMIZER) { SystemOptimizerScreen(viewModel) }
            composable(Routes.MORE) { MoreScreen(nav) }
            composable(Routes.DEEP_CLEAN) { DeepCleanScreen(viewModel) }
            composable(Routes.BOOST) { BoostScreen(viewModel) }
            composable(Routes.ZRAM) { ZramScreen(viewModel) }
            composable(Routes.APPS) { AppsScreen(viewModel) }
            composable(Routes.STORAGE) { StorageScreen(viewModel) }
            composable(Routes.GAME_BOOSTER) { GameBoosterScreen(viewModel) }
            composable(Routes.HISTORY) { HistoryScreen(viewModel) }
            composable(Routes.SETTINGS) { SettingsScreen(viewModel) }
        }
    }
}

private val secondaryRoutes = setOf(
    Routes.MORE, Routes.DEEP_CLEAN, Routes.BOOST, Routes.ZRAM, Routes.APPS,
    Routes.STORAGE, Routes.GAME_BOOSTER, Routes.HISTORY, Routes.SETTINGS
)
