package com.kaikodev.ramreset.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.SpaceDashboard
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.graphics.vector.ImageVector

/** Rotas do app. */
object Routes {
    const val SPLASH = "splash"
    const val DASHBOARD = "dashboard"
    const val MONITOR = "monitor"
    const val RESET = "reset"
    const val OPTIMIZER = "optimizer"
    const val MORE = "more"
    const val DEEP_CLEAN = "deep_clean"
    const val BOOST = "boost"
    const val ZRAM = "zram"
    const val APPS = "apps"
    const val STORAGE = "storage"
    const val GAME_BOOSTER = "game_booster"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
}

/** Itens da barra inferior. */
enum class BottomItem(val route: String, val label: String, val icon: ImageVector) {
    DASHBOARD(Routes.DASHBOARD, "Início", Icons.Filled.SpaceDashboard),
    MONITOR(Routes.MONITOR, "RAM", Icons.Filled.Memory),
    RESET(Routes.RESET, "Reset", Icons.Filled.RestartAlt),
    OPTIMIZER(Routes.OPTIMIZER, "Otimizar", Icons.Filled.Tune),
    MORE(Routes.MORE, "Mais", Icons.Filled.Apps)
}
