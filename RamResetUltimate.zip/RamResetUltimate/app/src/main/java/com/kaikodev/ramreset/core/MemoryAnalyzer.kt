package com.kaikodev.ramreset.core

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import com.kaikodev.ramreset.core.model.MemorySnapshot

/**
 * Lê o estado REAL de memória via APIs oficiais (seções 3.1 / 5).
 * Sem root, sem leitura de processos de terceiros.
 */
class MemoryAnalyzer(context: Context) {

    private val activityManager =
        context.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun snapshot(): MemorySnapshot {
        val mi = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(mi)   // preenche totalMem, availMem, threshold, lowMemory

        return MemorySnapshot(
            totalBytes = mi.totalMem,
            availableBytes = mi.availMem,
            thresholdBytes = mi.threshold,
            lowMemory = mi.lowMemory,
            appPssBytes = readOwnPssBytes()
        )
    }

    /**
     * PSS do PRÓPRIO processo. Debug.getMemoryInfo é local ao app — não requer permissão.
     * totalPss vem em KB; convertemos para bytes. Retorna -1 se a leitura falhar.
     */
    private fun readOwnPssBytes(): Long = try {
        val dbg = Debug.MemoryInfo()
        Debug.getMemoryInfo(dbg)
        dbg.totalPss.toLong() * 1024L
    } catch (t: Throwable) {
        -1L
    }
}
