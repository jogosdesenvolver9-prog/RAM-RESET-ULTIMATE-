package com.kaikodev.ramreset.core

import com.kaikodev.ramreset.core.model.MemorySnapshot
import com.kaikodev.ramreset.core.model.PressureLevel
import com.kaikodev.ramreset.core.model.PressureResult

/**
 * Classifica a pressão de memória (seção 3.3) a partir de indicadores reais.
 * Lógica pura e sem contexto Android → testável em JVM (PressureDetectorTest).
 *
 * Regras:
 *  - lowMemory == true do sistema sempre eleva para CRITICAL (sinal autoritativo).
 *  - Caso contrário, usa o percentual de uso com faixas conservadoras.
 *  - [estimated] fica true quando o total é inválido (dados insuficientes).
 */
object MemoryPressureDetector {

    fun evaluate(snapshot: MemorySnapshot): PressureResult {
        if (snapshot.totalBytes <= 0L) {
            return PressureResult(
                level = PressureLevel.NORMAL,
                usedPercent = 0,
                estimated = true,
                reason = "Dados de memória insuficientes; diagnóstico estimado."
            )
        }

        val used = snapshot.usedPercent

        if (snapshot.lowMemory) {
            return PressureResult(
                level = PressureLevel.CRITICAL,
                usedPercent = used,
                estimated = false,
                reason = "Sistema sinalizou estado de baixa memória (lowMemory)."
            )
        }

        val level = when {
            used >= 92 -> PressureLevel.CRITICAL
            used >= 85 -> PressureLevel.HIGH
            used >= 70 -> PressureLevel.MODERATE
            else -> PressureLevel.NORMAL
        }

        return PressureResult(
            level = level,
            usedPercent = used,
            estimated = false,
            reason = "Baseado em ${used}% de uso de RAM física."
        )
    }
}
