package com.kaikodev.ramreset.core.util

import java.util.Locale
import kotlin.math.abs

/** Conversões e formatação de unidades (testadas em UnitConversionTest). */
object Formatters {

    private const val KB = 1024.0
    private const val MB = KB * 1024.0
    private const val GB = MB * 1024.0

    /**
     * Formata bytes em string legível (base binária: 1 GB = 1024 MB).
     * Negativo é tratado como "—" (dado indisponível).
     */
    fun bytes(value: Long, decimals: Int = 1): String {
        if (value < 0) return "—"
        val v = value.toDouble()
        return when {
            v >= GB -> format(v / GB, decimals) + " GB"
            v >= MB -> format(v / MB, decimals) + " MB"
            v >= KB -> format(v / KB, decimals) + " KB"
            else -> "$value B"
        }
    }

    /** Diferença assinada: "+120 MB" / "-45 MB". Zero vira "0 B". */
    fun signedBytes(value: Long): String {
        if (value == 0L) return "0 B"
        val sign = if (value > 0) "+" else "-"
        return sign + bytes(abs(value))
    }

    fun percent(value: Int): String = "$value%"

    fun mb(bytes: Long): Int = if (bytes < 0) -1 else (bytes / (1024L * 1024L)).toInt()

    private fun format(value: Double, decimals: Int): String =
        String.format(Locale.US, "%.${decimals}f", value)
}
