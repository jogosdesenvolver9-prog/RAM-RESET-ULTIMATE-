package com.kaikodev.ramreset.core

import com.kaikodev.ramreset.core.model.ZramInfo
import java.io.File

/**
 * Investiga memória comprimida / swap (seção 4 / 6) SEM root.
 *
 * Fontes:
 *  - /proc/meminfo  → world-readable em praticamente todo Android. SwapTotal/SwapFree.
 *  - /sys/block/zram0/mm_stat → frequentemente bloqueado para apps comuns; tentamos e,
 *    se falhar, marcamos readLimited = true (honesto, seção 4: "não pressupor acesso").
 *
 * Nunca executa comandos privilegiados nem altera o kernel.
 */
class ZramReader {

    fun read(): ZramInfo {
        val meminfo = parseMeminfo()
        val swapTotal = meminfo["SwapTotal"]?.let { it * 1024L } ?: -1L
        val swapFree = meminfo["SwapFree"]?.let { it * 1024L } ?: -1L

        val zramBlock = File("/sys/block/zram0")
        val zramExists = zramBlock.exists()

        var dataBytes = -1L
        var comprBytes = -1L
        var limited = false

        if (zramExists) {
            // mm_stat: "orig_data_size compr_data_size mem_used_total ..."
            val mmStat = safeReadLine(File(zramBlock, "mm_stat"))
            if (mmStat != null) {
                val parts = mmStat.trim().split(Regex("\\s+"))
                if (parts.size >= 2) {
                    dataBytes = parts[0].toLongOrNull() ?: -1L
                    comprBytes = parts[1].toLongOrNull() ?: -1L
                }
            } else {
                limited = true
            }
        }

        val detected = zramExists || swapTotal > 0L

        val note = when {
            !detected -> "Nenhum dispositivo ZRAM ou swap detectado neste aparelho."
            limited -> "ZRAM presente, mas estatísticas detalhadas exigem privilégios não disponíveis sem root."
            dataBytes > 0 -> "ZRAM ativa; estatísticas de compressão lidas com sucesso."
            swapTotal > 0 -> "Swap detectado via /proc/meminfo."
            else -> "ZRAM detectada; leitura parcial."
        }

        return ZramInfo(
            zramDetected = detected,
            swapTotalBytes = swapTotal,
            swapFreeBytes = swapFree,
            zramDataBytes = dataBytes,
            zramCompressedBytes = comprBytes,
            readLimited = limited,
            note = note
        )
    }

    private fun parseMeminfo(): Map<String, Long> {
        val result = HashMap<String, Long>()
        try {
            File("/proc/meminfo").forEachLine { line ->
                // Ex.: "SwapTotal:       1048576 kB"
                val idx = line.indexOf(':')
                if (idx > 0) {
                    val key = line.substring(0, idx).trim()
                    val valueKb = line.substring(idx + 1)
                        .trim()
                        .removeSuffix(" kB")
                        .trim()
                        .toLongOrNull()
                    if (valueKb != null) result[key] = valueKb
                }
            }
        } catch (_: Throwable) {
            // /proc/meminfo inacessível (raro). Retorna mapa vazio → campos ficam -1.
        }
        return result
    }

    private fun safeReadLine(file: File): String? = try {
        if (file.canRead()) file.bufferedReader().use { it.readLine() } else null
    } catch (_: Throwable) {
        null
    }
}
