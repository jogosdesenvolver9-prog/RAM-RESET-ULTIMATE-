package com.kaikodev.ramreset.core.accessibility

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Estado compartilhado entre a UI e o CacheCleanAccessibilityService.
 * Como o serviço roda no mesmo processo do app, um singleton + StateFlow basta.
 */
object CleanSession {

    data class Progress(
        val active: Boolean = false,
        val total: Int = 0,
        val processed: Int = 0,
        val currentLabel: String = "",
        val finished: Boolean = false
    )

    private val _progress = MutableStateFlow(Progress())
    val progress: StateFlow<Progress> = _progress

    /** Fila de (packageName, label) a processar. Lida pelo serviço. */
    @Volatile
    var queue: List<Pair<String, String>> = emptyList()
        private set

    val isActive: Boolean get() = _progress.value.active

    fun begin(items: List<Pair<String, String>>) {
        queue = items
        _progress.value = Progress(
            active = true,
            total = items.size,
            processed = 0,
            currentLabel = items.firstOrNull()?.second ?: "",
            finished = false
        )
    }

    fun update(processed: Int, label: String) {
        _progress.value = _progress.value.copy(processed = processed, currentLabel = label)
    }

    fun finish() {
        _progress.value = _progress.value.copy(active = false, finished = true)
        queue = emptyList()
    }

    /** Limpa o estado "finished" depois que a UI já o exibiu. */
    fun acknowledge() {
        if (!_progress.value.active) _progress.value = Progress()
    }
}
