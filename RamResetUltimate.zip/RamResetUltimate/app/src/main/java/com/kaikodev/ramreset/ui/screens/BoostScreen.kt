package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kaikodev.ramreset.core.SystemShortcuts
import com.kaikodev.ramreset.core.model.UsageApp
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard
import com.kaikodev.ramreset.ui.theme.ElectricBlue
import com.kaikodev.ramreset.ui.theme.NeonPurple
import com.kaikodev.ramreset.ui.theme.Surface1

@Composable
fun BoostScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Recarrega ao entrar e ao voltar (ex.: depois de conceder "Acesso ao uso").
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.loadUsageApps()
        viewModel.refreshPerformance()
    }

    ScreenScaffold(title = "Boost", subtitle = "Apps recentes e desempenho") {

        SectionCard(title = "Menos lag — animações") {
            Text(
                state.lagHint.ifEmpty { "Lendo configuração de animações…" },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(
                onClick = { SystemShortcuts.openDeveloperSettings(context) },
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) { Text("Abrir Opções do desenvolvedor") }
            Text(
                "Nas Opções do desenvolvedor, ajuste \"Escala de animação\" para 0,5x. " +
                    "O Android bloqueia apps de mudar isso sozinhos sem ADB — por isso o atalho.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        if (!state.hasUsageAccess) {
            SectionCard(title = "Apps em segundo plano") {
                Text(
                    "Para listar apps usados recentemente (candidatos a fechar), conceda a permissão " +
                        "\"Acesso ao uso\". É opcional e você pode revogar quando quiser.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { SystemShortcuts.openUsageAccessSettings(context) },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                ) { Text("Conceder 'Acesso ao uso'", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
            }
        } else {
            SectionCard(title = "Usados recentemente (${state.usageApps.size})") {
                Text(
                    "Toque num app para abrir suas informações e usar \"Forçar parada\". " +
                        "O Android não deixa fechar apps em massa automaticamente — e reabrir serviços " +
                        "essenciais logo depois gastaria mais bateria.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }
            state.usageApps.forEach { app ->
                UsageRow(app) { SystemShortcuts.openAppDetails(context, app.packageName) }
            }
        }
    }
}

@Composable
private fun UsageRow(app: UsageApp, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Surface1)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(app.label, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
            Text(
                "Último uso: ${timeAgo(app.lastUsedMs)}",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )
        }
    }
}

private fun timeAgo(ms: Long): String {
    val diff = System.currentTimeMillis() - ms
    val min = diff / 60000
    return when {
        min < 1 -> "agora há pouco"
        min < 60 -> "$min min atrás"
        else -> "${min / 60}h atrás"
    }
}
