package com.kaikodev.ramreset.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kaikodev.ramreset.core.model.PressureLevel
import com.kaikodev.ramreset.ui.theme.DeepBlack
import com.kaikodev.ramreset.ui.theme.StateCritical
import com.kaikodev.ramreset.ui.theme.StateHigh
import com.kaikodev.ramreset.ui.theme.StateModerate
import com.kaikodev.ramreset.ui.theme.StateNormal
import com.kaikodev.ramreset.ui.theme.Surface1
import com.kaikodev.ramreset.ui.theme.Surface2

/** Fundo com gradiente sutil (seção 10). */
@Composable
fun GradientBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(DeepBlack, Color(0xFF0A0616), DeepBlack)
                )
            )
    ) { content() }
}

/** Card premium com profundidade. */
@Composable
fun SectionCard(
    title: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Surface1),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            if (title != null) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 6.dp))
            }
            content()
        }
    }
}

// Alias para permitir content: ColumnScope.() dentro de SectionCard.
typealias ColumnScope = androidx.compose.foundation.layout.ColumnScope

/** Linha chave → valor, usada em todas as telas de diagnóstico. */
@Composable
fun InfoRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

/** Mini-card de estatística (grid do dashboard). */
@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Surface2)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Selo colorido do nível de pressão (seção 3.3). */
@Composable
fun PressureBadge(level: PressureLevel, estimated: Boolean) {
    val (color, text) = when (level) {
        PressureLevel.NORMAL -> StateNormal to "NORMAL"
        PressureLevel.MODERATE -> StateModerate to "MODERADA"
        PressureLevel.HIGH -> StateHigh to "ALTA"
        PressureLevel.CRITICAL -> StateCritical to "CRÍTICA"
    }
    Box(
        Modifier
            .background(color.copy(alpha = 0.18f), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (estimated) "$text (estimada)" else text,
            color = color,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge
        )
    }
}
