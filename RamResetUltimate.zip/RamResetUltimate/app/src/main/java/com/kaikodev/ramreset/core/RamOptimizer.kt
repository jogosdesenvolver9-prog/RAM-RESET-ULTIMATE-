package com.kaikodev.ramreset.core

import android.content.ComponentCallbacks2
import android.content.Context
import java.io.File

/**
 * Operações REAIS de otimização, restritas ao PRÓPRIO app (seções 3.2 / 4).
 *
 * O que é honestamente possível sem root:
 *  - apagar o cache interno/externo do próprio app (bytes mensuráveis);
 *  - pedir ao runtime que colete lixo e finalize objetos (hint, não garantido);
 *  - sinalizar onTrimMemory para liberar buffers internos (Compose/bitmaps).
 *
 * O que NÃO é possível (e o engine reporta como indisponível):
 *  - matar processos de terceiros;
 *  - liberar RAM de outros apps;
 *  - "resetar"/aumentar a RAM física do aparelho.
 */
class RamOptimizer(context: Context) {

    private val appContext = context.applicationContext

    /** Apaga o cache do próprio app. Retorna bytes efetivamente liberados (medido antes/depois). */
    fun clearOwnCache(): Long {
        val before = cacheSize()
        deleteContents(appContext.cacheDir)
        appContext.externalCacheDir?.let { deleteContents(it) }
        val after = cacheSize()
        return (before - after).coerceAtLeast(0L)
    }

    /**
     * Pede liberação de memória não essencial ao próprio processo.
     * onTrimMemory(TRIM_MEMORY_RUNNING_CRITICAL) faz componentes (ex.: Compose) soltarem caches.
     */
    fun trimOwnMemory() {
        try {
            appContext.onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL)
        } catch (_: Throwable) { /* no-op */ }
    }

    /** Hint de coleta de lixo. O runtime decide o momento — por isso é "hint", não garantia. */
    fun requestGc() {
        Runtime.getRuntime().gc()
        System.runFinalization()
        Runtime.getRuntime().gc()
    }

    private fun cacheSize(): Long {
        var sum = dirSize(appContext.cacheDir)
        appContext.externalCacheDir?.let { sum += dirSize(it) }
        return sum
    }

    private fun deleteContents(dir: File?) {
        if (dir == null || !dir.isDirectory) return
        dir.listFiles()?.forEach { child ->
            try {
                if (child.isDirectory) deleteContents(child)
                child.delete()
            } catch (_: Throwable) { /* ignora arquivos em uso */ }
        }
    }

    private fun dirSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        return try {
            dir.walkBottomUp().filter { it.isFile }.map { it.length() }.sum()
        } catch (_: Throwable) {
            0L
        }
    }
}
