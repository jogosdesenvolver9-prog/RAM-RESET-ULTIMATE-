package com.kaikodev.ramreset

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.navigation.RamResetNavHost
import com.kaikodev.ramreset.ui.theme.RamResetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            RamResetTheme {
                val vm: MainViewModel = viewModel(factory = MainViewModel.factory(applicationContext))
                RamResetNavHost(viewModel = vm)
            }
        }
    }
}
