package com.kaikodev.ramreset.core

import android.content.Context
import com.kaikodev.ramreset.core.model.MemorySnapshot
import com.kaikodev.ramreset.core.model.PressureLevel
import com.kaikodev.ramreset.core.model.ResetReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * RESET ENGINE — orquestra o fluxo de otimização (seções 3 / 6 / 12).
 *
 * Fluxo honesto:
 *  1. mede a RAM antes;
 *  2. avalia a pressão de memória;
 *  3. executa SÓ operações reais e permitidas (próprio app);
 *  4. mede a RAM depois;
 *  5. monta um relatório com o que foi feito, o que é indisponível e o delta medido.
 *
 * Nunca declara "RAM liberada" sem evidência: o ganho comprovado é o do próprio app.
 */
class ResetEngine(context: Context) {

    private val analyzer = MemoryAnalyzer(context)
    private val optimizer = RamOptimizer(context)

    /** Operações que NÃO são possíveis sem root/privilégio — reportadas com transparência. */
    private val unavailableOps = listOf(
        "Encerrar processos de outros apps (bloqueado pelo Android sem root)",
        "Liberar RAM usada por outros aplicativos (gerenciada pelo sistema)",
        "Aumentar a RAM física do aparelho (impossível por software)",
        "Alterar parâmetros de ZRAM/kernel (exige root)"
    )

    suspend fun run(): ResetReport = withContext(Dispatchers.Default) {
        val before = analyzer.snapshot()
        val pressure = MemoryPressureDetector.evaluate(before)

        val done = ArrayList<String>()

        // 1) Liberar cache do próprio app (mensurável).
        val freed = optimizer.clearOwnCache()
        done += if (freed > 0)
            "Cache interno do app apagado (${freed} bytes)"
        else
            "Cache interno do app verificado (nada relevante para apagar)"

        // 2) Pedir trim de memória ao próprio processo.
        optimizer.trimOwnMemory()
        done += "Solicitada liberação de buffers internos (onTrimMemory)"

        // 3) Hint de GC e finalização.
        optimizer.requestGc()
        done += "Coleta de lixo e finalização solicitadas ao runtime"

        // Pequena espera para o runtime estabilizar antes de remedir (não é cosmético:
        // dá tempo de GC/finalização refletirem no PSS).
        delay(350)

        val after = analyzer.snapshot()

        ResetReport(
            timestampMs = System.currentTimeMillis(),
            before = before,
            after = after,
            ownCacheFreedBytes = freed,
            operationsDone = done,
            operationsUnavailable = unavailableOps,
            recommendations = buildRecommendations(before, pressure.level)
        )
    }

    private fun buildRecommendations(
        before: MemorySnapshot,
        level: PressureLevel
    ): List<String> {
        val recs = ArrayList<String>()
        when (level) {
            PressureLevel.CRITICAL, PressureLevel.HIGH -> {
                recs += "Feche manualmente apps pesados que você não está usando."
                recs += "Reiniciar o aparelho é a forma mais eficaz de liberar RAM real."
                recs += "Use os atalhos do Smart Optimizer para abrir as configurações do app."
            }
            PressureLevel.MODERATE -> {
                recs += "Uso de memória moderado; feche abas/apps em segundo plano se notar lentidão."
            }
            PressureLevel.NORMAL -> {
                recs += "Memória saudável. O Android já está gerenciando bem a RAM."
            }
        }
        if (before.lowMemory) {
            recs += "O sistema está em baixa memória: evite abrir novos apps pesados agora."
        }
        return recs
    }
}
