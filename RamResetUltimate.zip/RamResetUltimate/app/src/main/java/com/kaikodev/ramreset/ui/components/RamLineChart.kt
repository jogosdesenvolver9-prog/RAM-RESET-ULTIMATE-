package com.kaikodev.ramreset.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.kaikodev.ramreset.ui.theme.ElectricBlue
import com.kaikodev.ramreset.ui.theme.NeonPurple

/**
 * Gráfico de linha com HISTÓRICO REAL de uso de RAM (seção 5: "não números aleatórios").
 * Recebe uma lista de percentuais 0..100 na ordem temporal.
 */
@Composable
fun RamLineChart(
    data: List<Int>,
    modifier: Modifier = Modifier
) {
    if (data.size < 2) {
        Text(
            "Coletando histórico de memória…",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = modifier
        )
        return
    }

    val fill = Brush.verticalGradient(listOf(NeonPurple.copy(alpha = 0.35f), ElectricBlue.copy(alpha = 0f)))

    Canvas(modifier = modifier.fillMaxWidth().height(120.dp)) {
        val w = size.width
        val h = size.height
        val stepX = w / (data.size - 1)
        fun y(p: Int) = h - (p.coerceIn(0, 100) / 100f) * h

        val line = Path().apply {
            moveTo(0f, y(data[0]))
            for (i in 1 until data.size) lineTo(i * stepX, y(data[i]))
        }
        val area = Path().apply {
            addPath(line)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(area, brush = fill)
        drawPath(
            path = line,
            brush = Brush.horizontalGradient(listOf(ElectricBlue, NeonPurple)),
            style = Stroke(width = 4f)
        )
        // Ponto atual.
        drawCircle(
            color = NeonPurple,
            radius = 6f,
            center = Offset((data.size - 1) * stepX, y(data.last()))
        )
    }
}
