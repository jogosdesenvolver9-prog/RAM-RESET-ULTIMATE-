package com.kaikodev.ramreset.core.model

/**
 * Nível de pressão de memória (seção 3.3).
 * [estimated] = true quando faltam dados confiáveis e a classificação é aproximada.
 */
enum class PressureLevel { NORMAL, MODERATE, HIGH, CRITICAL }

data class PressureResult(
    val level: PressureLevel,
    val usedPercent: Int,
    val estimated: Boolean,
    val reason: String
)
