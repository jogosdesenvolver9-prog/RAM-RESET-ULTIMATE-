package com.kaikodev.ramreset.ui.screens

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.kaikodev.ramreset.core.SystemShortcuts
import com.kaikodev.ramreset.ui.MainViewModel
import com.kaikodev.ramreset.ui.components.InfoRow
import com.kaikodev.ramreset.ui.components.ScreenScaffold
import com.kaikodev.ramreset.ui.components.SectionCard

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val context = LocalContext.current

    ScreenScaffold(title = "Configurações") {
        SectionCard(title = "Sobre") {
            InfoRow("Aplicativo", "RAM Reset Ultimate")
            InfoRow("Desenvolvedor", "KAIKODEV")
            InfoRow("Pacote", "com.kaikodev.ramreset")
            InfoRow("Versão", "1.0.0")
            InfoRow("Requer root", "Não")
        }

        SectionCard(title = "Permissões opcionais") {
            Text(
                "O app funciona sem permissões especiais. O 'Acesso ao uso' é opcional e só " +
                    "serve para enriquecer estatísticas de apps. Você concede manualmente:",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(
                onClick = { SystemShortcuts.openUsageAccessSettings(context) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Abrir 'Acesso ao uso'") }
        }

        SectionCard(title = "Dados") {
            OutlinedButton(
                onClick = { viewModel.clearHistory() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Limpar histórico de otimizações") }
        }

        SectionCard(title = "Transparência") {
            Text(
                "Este app não coleta dados pessoais, não envia nada para a internet e não exige " +
                    "root. Toda a leitura de memória usa APIs oficiais do Android. Operações que " +
                    "exigiriam root (como encerrar outros apps ou aumentar a RAM física) não são " +
                    "prometidas nem simuladas.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
