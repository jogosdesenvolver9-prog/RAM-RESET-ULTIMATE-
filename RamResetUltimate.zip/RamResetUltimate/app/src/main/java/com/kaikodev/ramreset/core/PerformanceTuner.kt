package com.kaikodev.ramreset.core

import android.content.Context
import android.provider.Settings

/**
 * Ajustes de desempenho / "menos lag" (seção 7).
 *
 * HONESTO: reduzir a escala de animações deixa o aparelho MAIS responsivo (menos lag
 * percebido). Porém mudar esse valor exige WRITE_SECURE_SETTINGS, que só é concedida via
 * ADB/root. Então LEMOS o valor atual (permitido) e levamos o usuário às Opções do
 * desenvolvedor para ajustar com um toque. Não prometemos mudar sozinhos o que o Android bloqueia.
 */
class PerformanceTuner(context: Context) {

    private val resolver = context.applicationContext.contentResolver

    data class AnimationScales(
        val window: Float,
        val transition: Float,
        val animator: Float
    ) {
        val allReduced: Boolean get() = window <= 0.5f && transition <= 0.5f && animator <= 0.5f
        val average: Float get() = (window + transition + animator) / 3f
    }

    fun readAnimationScales(): AnimationScales = AnimationScales(
        window = getGlobalFloat(Settings.Global.WINDOW_ANIMATION_SCALE),
        transition = getGlobalFloat(Settings.Global.TRANSITION_ANIMATION_SCALE),
        animator = getGlobalFloat(Settings.Global.ANIMATOR_DURATION_SCALE)
    )

    private fun getGlobalFloat(key: String): Float = try {
        Settings.Global.getFloat(resolver, key, 1.0f)
    } catch (_: Throwable) {
        1.0f
    }

    /** Dica textual conforme o estado atual das animações. */
    fun lagHint(scales: AnimationScales): String = when {
        scales.allReduced -> "Animações já reduzidas — ótimo para responsividade."
        scales.average >= 1.0f -> "Animações em escala padrão. Reduzi-las para 0,5x deixa o aparelho mais rápido."
        else -> "Animações parcialmente reduzidas. Deixe todas em 0,5x para o máximo de fluidez."
    }
}
