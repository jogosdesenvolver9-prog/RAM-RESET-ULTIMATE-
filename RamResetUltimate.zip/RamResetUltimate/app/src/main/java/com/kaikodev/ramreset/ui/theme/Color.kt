package com.kaikodev.ramreset.ui.theme

import androidx.compose.ui.graphics.Color

// Identidade "Premium Futuristic Performance" (seção 10):
// preto profundo, roxo neon, azul elétrico.
val DeepBlack = Color(0xFF05030A)
val Surface1 = Color(0xFF0E0A1A)
val Surface2 = Color(0xFF151029)
val NeonPurple = Color(0xFFA855F7)
val ElectricBlue = Color(0xFF38BDF8)
val NeonViolet = Color(0xFF7C3AED)
val TextPrimary = Color(0xFFF5F3FF)
val TextSecondary = Color(0xFFA9A3C2)

// Estados de pressão de memória.
val StateNormal = Color(0xFF22C55E)
val StateModerate = Color(0xFFEAB308)
val StateHigh = Color(0xFFF97316)
val StateCritical = Color(0xFFEF4444)
