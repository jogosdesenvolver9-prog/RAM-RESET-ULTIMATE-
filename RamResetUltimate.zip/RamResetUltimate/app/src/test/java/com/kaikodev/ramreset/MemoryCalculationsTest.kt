package com.kaikodev.ramreset

import com.kaikodev.ramreset.core.model.MemorySnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Testa os cálculos de memória do MemorySnapshot (seção 14). */
class MemoryCalculationsTest {

    private fun snap(total: Long, avail: Long, pss: Long = -1, low: Boolean = false) =
        MemorySnapshot(
            totalBytes = total,
            availableBytes = avail,
            thresholdBytes = 0,
            lowMemory = low,
            appPssBytes = pss
        )

    @Test
    fun usedBytes_is_total_minus_available() {
        val s = snap(4_000_000_000, 1_000_000_000)
        assertEquals(3_000_000_000, s.usedBytes)
    }

    @Test
    fun usedPercent_is_correct() {
        val s = snap(4_000, 1_000) // 75% usado
        assertEquals(75, s.usedPercent)
        assertEquals(25, s.availablePercent)
    }

    @Test
    fun usedBytes_never_negative_when_available_exceeds_total() {
        // Dado inconsistente não deve gerar valor negativo.
        val s = snap(1_000, 2_000)
        assertEquals(0, s.usedBytes)
    }

    @Test
    fun zero_total_yields_zero_percent_not_crash() {
        val s = snap(0, 0)
        assertEquals(0, s.usedPercent)
    }

    @Test
    fun percent_is_clamped_between_0_and_100() {
        val s = snap(1_000, 0)
        assertTrue(s.usedPercent in 0..100)
        assertEquals(100, s.usedPercent)
    }
}
