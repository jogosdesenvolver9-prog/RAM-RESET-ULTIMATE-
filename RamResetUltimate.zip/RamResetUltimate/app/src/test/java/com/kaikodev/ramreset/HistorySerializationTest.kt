package com.kaikodev.ramreset

import com.kaikodev.ramreset.data.HistoryEntry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Testa serialização/desserialização do histórico (seção 14: histórico). */
class HistorySerializationTest {

    @Test
    fun round_trip_preserves_values() {
        val original = HistoryEntry(
            timestampMs = 1_700_000_000_000,
            availableBeforeBytes = 1_000_000,
            availableAfterBytes = 1_200_000,
            ownCacheFreedBytes = 50_000,
            provenFreedBytes = 70_000,
            usedPercentBefore = 80,
            usedPercentAfter = 76
        )
        val restored = HistoryEntry.deserialize(original.serialize())
        assertEquals(original, restored)
    }

    @Test
    fun malformed_string_returns_null() {
        assertNull(HistoryEntry.deserialize("lixo|incompleto"))
        assertNull(HistoryEntry.deserialize(""))
        assertNull(HistoryEntry.deserialize("a|b|c|d|e|f|g")) // 7 campos mas não-numéricos
    }
}
