package com.kaikodev.ramreset

import com.kaikodev.ramreset.core.util.Formatters
import org.junit.Assert.assertEquals
import org.junit.Test

/** Testa conversão e formatação de unidades (seção 14). */
class UnitConversionTest {

    @Test
    fun formats_gigabytes() {
        assertEquals("1.0 GB", Formatters.bytes(1024L * 1024 * 1024))
    }

    @Test
    fun formats_megabytes() {
        assertEquals("1.0 MB", Formatters.bytes(1024L * 1024))
    }

    @Test
    fun formats_kilobytes() {
        assertEquals("2.0 KB", Formatters.bytes(2048L))
    }

    @Test
    fun formats_bytes_below_kb() {
        assertEquals("512 B", Formatters.bytes(512L))
    }

    @Test
    fun negative_is_dash() {
        assertEquals("—", Formatters.bytes(-1L))
    }

    @Test
    fun signed_positive_has_plus() {
        assertEquals("+1.0 MB", Formatters.signedBytes(1024L * 1024))
    }

    @Test
    fun signed_zero_is_zero_bytes() {
        assertEquals("0 B", Formatters.signedBytes(0L))
    }

    @Test
    fun mb_helper_converts_correctly() {
        assertEquals(256, Formatters.mb(256L * 1024 * 1024))
    }
}
