package com.kaikodev.ramreset

import com.kaikodev.ramreset.core.MemoryPressureDetector
import com.kaikodev.ramreset.core.model.MemorySnapshot
import com.kaikodev.ramreset.core.model.PressureLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Testa a classificação de pressão de memória (seções 3.3 / 14). */
class PressureDetectorTest {

    private fun snap(total: Long, avail: Long, low: Boolean = false) =
        MemorySnapshot(total, avail, 0, low, -1)

    @Test
    fun normal_when_usage_low() {
        val r = MemoryPressureDetector.evaluate(snap(1000, 600)) // 40% usado
        assertEquals(PressureLevel.NORMAL, r.level)
        assertFalse(r.estimated)
    }

    @Test
    fun moderate_at_70_plus() {
        val r = MemoryPressureDetector.evaluate(snap(1000, 250)) // 75% usado
        assertEquals(PressureLevel.MODERATE, r.level)
    }

    @Test
    fun high_at_85_plus() {
        val r = MemoryPressureDetector.evaluate(snap(1000, 120)) // 88% usado
        assertEquals(PressureLevel.HIGH, r.level)
    }

    @Test
    fun critical_at_92_plus() {
        val r = MemoryPressureDetector.evaluate(snap(1000, 50)) // 95% usado
        assertEquals(PressureLevel.CRITICAL, r.level)
    }

    @Test
    fun lowMemory_flag_forces_critical() {
        // Mesmo com uso aparentemente baixo, lowMemory do sistema manda.
        val r = MemoryPressureDetector.evaluate(snap(1000, 900, low = true))
        assertEquals(PressureLevel.CRITICAL, r.level)
    }

    @Test
    fun invalid_total_is_estimated() {
        val r = MemoryPressureDetector.evaluate(snap(0, 0))
        assertTrue(r.estimated)
    }
}
