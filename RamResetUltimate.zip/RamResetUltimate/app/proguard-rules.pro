# Keep data model classes (used for history serialization / reflection safety)
-keep class com.kaikodev.ramreset.core.model.** { *; }
-keepclassmembers class com.kaikodev.ramreset.core.model.** { *; }
